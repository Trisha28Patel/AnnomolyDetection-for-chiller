"""
Chiller Energy Data Analysis & Machine Learning Package
-------------------------------------------------------
End-to-end data processing, feature engineering, modeling, and visualization
for industrial smart energy meter data.
"""

__version__ = "1.0.0"
__author__ = "Data Science & Energy Analytics Intern"

