"""
Interactive Plotly Visualization Library
Produces clean, publication-quality interactive charts for Streamlit and Jupyter.
"""

import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np


def plot_power_timeseries(df: pd.DataFrame, start_date=None, end_date=None) -> go.Figure:
    """
    Plots Active Power over time with phase breakdown and interactive range slider.
    """
    plot_df = df.copy()
    if start_date and end_date:
        plot_df = plot_df[(plot_df['timestamp'] >= pd.to_datetime(start_date)) & 
                          (plot_df['timestamp'] <= pd.to_datetime(end_date))]
        
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=plot_df['timestamp'], y=plot_df['power_kw'],
        mode='lines', name='Total Active Power (kW)',
        line=dict(color='#1f77b4', width=2)
    ))
    fig.add_trace(go.Scatter(
        x=plot_df['timestamp'], y=plot_df['power_r_kw'],
        mode='lines', name='Phase R (kW)',
        line=dict(color='#d62728', width=1, dash='dot'),
        visible='legendonly'
    ))
    fig.add_trace(go.Scatter(
        x=plot_df['timestamp'], y=plot_df['power_y_kw'],
        mode='lines', name='Phase Y (kW)',
        line=dict(color='#bcbd22', width=1, dash='dot'),
        visible='legendonly'
    ))
    fig.add_trace(go.Scatter(
        x=plot_df['timestamp'], y=plot_df['power_b_kw'],
        mode='lines', name='Phase B (kW)',
        line=dict(color='#17becf', width=1, dash='dot'),
        visible='legendonly'
    ))
    
    fig.update_layout(
        title='Chiller 1 Active Power Over Time (kW)',
        xaxis_title='Timestamp (IST)',
        yaxis_title='Active Power (kW)',
        template='plotly_white',
        hovermode='x unified',
        height=450,
        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1)
    )
    return fig


def plot_daily_energy(df: pd.DataFrame) -> go.Figure:
    """
    Plots daily energy consumption in kWh across all 31 days with cost annotation.
    """
    temp_df = df.copy()
    temp_df['date'] = temp_df['timestamp'].dt.date
    daily = temp_df.groupby('date').apply(
        lambda g: (g['power_kw'] * g['delta_hours']).sum(), include_groups=False
    ).reset_index(name='energy_kwh')
    daily['cost_inr'] = daily['energy_kwh'] * 8.50
    daily['date_str'] = daily['date'].astype(str)
    
    # Identify duty rotation: Days > 1000 kWh vs idle days
    daily['status'] = np.where(daily['energy_kwh'] > 2000, 'Full Duty Day (>2,000 kWh)',
                      np.where(daily['energy_kwh'] > 100, 'Partial / Top-Up Run', 'Standby / Idle (<100 kWh)'))
    
    color_map = {
        'Full Duty Day (>2,000 kWh)': '#2ca02c',
        'Partial / Top-Up Run': '#ff7f0e',
        'Standby / Idle (<100 kWh)': '#7f7f7f'
    }
    
    fig = px.bar(
        daily, x='date_str', y='energy_kwh',
        color='status',
        color_discrete_map=color_map,
        labels={'date_str': 'Date (Oct 2026)', 'energy_kwh': 'Energy (kWh)', 'status': 'Operating Regime'},
        title='Daily Energy Consumption (kWh) - Oct 2026 (Clear Duty Rotation Pattern)'
    )
    fig.update_layout(
        template='plotly_white',
        xaxis_tickangle=-45,
        height=450,
        hovermode='x unified',
        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1)
    )
    return fig


def plot_hourly_load_profile(df: pd.DataFrame) -> go.Figure:
    """
    Plots mean, 25th, and 75th percentile power by hour of day for running periods.
    """
    df_run = df[df['is_running']].copy()
    df_run['hour'] = df_run['timestamp'].dt.hour
    
    hourly = df_run.groupby('hour')['power_kw'].agg(
        mean='mean',
        median='median',
        p25=lambda x: x.quantile(0.25),
        p75=lambda x: x.quantile(0.75),
        p_max='max',
        p_min='min'
    ).reset_index()
    
    fig = go.Figure()
    # 25-75th percentile band
    fig.add_trace(go.Scatter(
        x=hourly['hour'], y=hourly['p75'],
        mode='lines', line=dict(width=0),
        showlegend=False, hoverinfo='skip'
    ))
    fig.add_trace(go.Scatter(
        x=hourly['hour'], y=hourly['p25'],
        mode='lines', line=dict(width=0),
        fill='tonexty', fillcolor='rgba(31, 119, 180, 0.2)',
        name='Interquartile Range (25%-75%)', hoverinfo='skip'
    ))
    fig.add_trace(go.Scatter(
        x=hourly['hour'], y=hourly['mean'],
        mode='lines+markers', name='Mean Power (kW)',
        line=dict(color='#1f77b4', width=3),
        marker=dict(size=7)
    ))
    fig.add_trace(go.Scatter(
        x=hourly['hour'], y=hourly['p_max'],
        mode='lines', name='Max Power (kW)',
        line=dict(color='#d62728', dash='dash', width=1.5)
    ))
    
    fig.update_layout(
        title='Diurnal Running Load Profile by Hour of Day (Peak at 11:00 AM)',
        xaxis=dict(title='Hour of Day (0 - 23)', dtick=1),
        yaxis=dict(title='Active Power (kW)'),
        template='plotly_white',
        height=450,
        hovermode='x unified',
        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1)
    )
    return fig


def plot_phase_balance(df: pd.DataFrame) -> go.Figure:
    """
    Plots Phase Current Imbalance percentage over time with 5% threshold line.
    """
    df_run = df[df['is_running']].copy()
    
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df_run['timestamp'], y=df_run['current_imbalance_pct'],
        mode='lines', name='Current Imbalance (%)',
        line=dict(color='#ff7f0e', width=1.5)
    ))
    fig.add_hline(
        y=5.0, line_dash='dash', line_color='red',
        annotation_text='5.0% NEMA Motor Standard Limit',
        annotation_position='top left'
    )
    
    fig.update_layout(
        title='Phase Current Imbalance (%) During Running Periods',
        xaxis_title='Timestamp',
        yaxis_title='Current Imbalance (%)',
        template='plotly_white',
        height=450,
        hovermode='x unified'
    )
    return fig


def plot_forecast_comparison(predictions_df: pd.DataFrame) -> go.Figure:
    """
    Plots Actual vs Gradient Boosting vs Persistence baseline for the test week.
    """
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=predictions_df.index, y=predictions_df['actual'],
        mode='lines', name='Actual Power (kW)',
        line=dict(color='#000000', width=2.5)
    ))
    fig.add_trace(go.Scatter(
        x=predictions_df.index, y=predictions_df['gradient_boosting'],
        mode='lines', name='Gradient Boosting (GBR)',
        line=dict(color='#2ca02c', width=2)
    ))
    fig.add_trace(go.Scatter(
        x=predictions_df.index, y=predictions_df['persistence'],
        mode='lines', name='Persistence Baseline (t-1)',
        line=dict(color='#1f77b4', dash='dot', width=1.5)
    ))
    
    fig.update_layout(
        title='Task C1: 15-Minute Ahead Power Forecast vs Actual (Test Week: Oct 25-31)',
        xaxis_title='Timestamp (IST)',
        yaxis_title='Active Power (kW)',
        template='plotly_white',
        height=480,
        hovermode='x unified',
        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1)
    )
    return fig


def plot_anomaly_scatter(tidy_df: pd.DataFrame, anomalies_df: pd.DataFrame) -> go.Figure:
    """
    Overlays flagged anomaly points on the continuous power time series.
    """
    fig = go.Figure()
    # Baseline power
    fig.add_trace(go.Scatter(
        x=tidy_df['timestamp'], y=tidy_df['power_kw'],
        mode='lines', name='Active Power (kW)',
        line=dict(color='#aec7e8', width=1)
    ))
    # Flagged points
    fig.add_trace(go.Scatter(
        x=anomalies_df['timestamp'], y=anomalies_df['power_kw'],
        mode='markers', name='Flagged Anomalies (Isolation Forest)',
        marker=dict(color='#d62728', size=7, symbol='x')
    ))
    
    fig.update_layout(
        title='Task C2: Anomaly Detection During Chiller Running Periods',
        xaxis_title='Timestamp',
        yaxis_title='Active Power (kW)',
        template='plotly_white',
        height=480,
        hovermode='closest',
        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1)
    )
    return fig

