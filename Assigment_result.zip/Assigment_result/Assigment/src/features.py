"""
Feature Engineering and Resampling Module for Machine Learning
"""

import pandas as pd
import numpy as np
from typing import Tuple, List


def resample_to_15min(tidy_df: pd.DataFrame) -> pd.DataFrame:
    """
    Resample cleaned 2-minute sensor data to regular 15-minute intervals.
    Aggregates active power using interval mean.
    
    Handling intervals with no readings:
    - In our audit of the October 2026 dataset, sampling gaps never exceed 7.0 minutes.
    - Thus, every single 15-minute window contains 7 to 8 raw readings.
    - In the general case, any missing interval is forward-filled (persistence)
      or interpolated, with remaining NaNs filled by 0.0 (chiller standby).
    """
    df_indexed = tidy_df.set_index('timestamp')
    resampled = df_indexed.resample('15min').agg({
        'power_kw': 'mean',
        'current_avg_a': 'mean',
        'current_r_a': 'mean',
        'current_y_a': 'mean',
        'current_b_a': 'mean',
        'current_imbalance_pct': 'mean',
        'power_factor': 'mean'
    })
    
    # Fill any potential missing intervals safely
    resampled['power_kw'] = resampled['power_kw'].interpolate(method='time').fillna(0.0)
    for col in resampled.columns:
        if col != 'power_kw':
            resampled[col] = resampled[col].ffill().bfill()
            
    return resampled


def build_forecasting_features(resampled_15: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
    """
    Constructs rich feature matrix for 15-minute ahead power forecasting.
    Features:
    1. Lagged Power Values:
       - lag_1: power at t-1 (15 min ago)
       - lag_2: power at t-2 (30 min ago)
       - lag_4: power at t-4 (1 hour ago)
       - lag_8: power at t-8 (2 hours ago)
       - lag_96: power at t-96 (24 hours ago, same time yesterday)
    2. Rolling Statistical Windows (lagged by 1 to prevent data leakage):
       - rolling_mean_4: 1-hour moving average
       - rolling_std_4: 1-hour moving standard deviation
       - rolling_mean_24: 6-hour moving average
       - rolling_mean_96: 24-hour moving average
    3. Temporal and Calendar Features:
       - hour: integer 0-23
       - minute: integer {0, 15, 30, 45}
       - dayofweek: integer 0-6 (Mon-Sun)
       - is_weekend: binary indicator
       - hour_sin / hour_cos: cyclical Fourier encoding of the 24-hour cycle
    4. Operational Schedule & State Features:
       - prev_is_running: binary indicator if chiller was running at t-1 (>= 10 kW)
    """
    df = resampled_15.copy()
    
    # Lags
    df['lag_1'] = df['power_kw'].shift(1)
    df['lag_2'] = df['power_kw'].shift(2)
    df['lag_4'] = df['power_kw'].shift(4)
    df['lag_8'] = df['power_kw'].shift(8)
    df['lag_96'] = df['power_kw'].shift(96)
    
    # Rolling features (shift(1) ensures no lookahead bias)
    shifted_power = df['power_kw'].shift(1)
    df['rolling_mean_4'] = shifted_power.rolling(4).mean()
    df['rolling_std_4'] = shifted_power.rolling(4).std().fillna(0)
    df['rolling_mean_24'] = shifted_power.rolling(24).mean()
    df['rolling_mean_96'] = shifted_power.rolling(96).mean()
    
    # Calendar & Cyclical
    df['hour'] = df.index.hour
    df['minute'] = df.index.minute
    df['dayofweek'] = df.index.dayofweek
    df['is_weekend'] = df['dayofweek'].isin([5, 6]).astype(int)
    df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24.0)
    df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24.0)
    
    # Prior operational state
    df['prev_is_running'] = (df['lag_1'] >= 10.0).astype(int)
    
    feature_cols = [
        'lag_1', 'lag_2', 'lag_4', 'lag_8', 'lag_96',
        'rolling_mean_4', 'rolling_std_4', 'rolling_mean_24', 'rolling_mean_96',
        'hour', 'hour_sin', 'hour_cos', 'dayofweek', 'is_weekend',
        'prev_is_running'
    ]
    
    # Drop warm-up rows containing NaNs from lag_96
    clean_features_df = df.dropna().copy()
    
    return clean_features_df, feature_cols

