"""
Operational Run Period Extraction and K-Means Clustering Module (Stretch Task 1)
"""

import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from typing import Tuple, Dict, Any


def extract_run_periods(tidy_df: pd.DataFrame) -> pd.DataFrame:
    """
    Identifies continuous chiller operational runs, calculating:
    - start time, end time, duration (hours and minutes)
    - mean power (kW), maximum power (kW)
    - start hour of the day (float)
    """
    df = tidy_df.sort_values('timestamp').reset_index(drop=True)
    df['run_change'] = df['is_running'] != df['is_running'].shift(1)
    df['run_id'] = df['run_change'].cumsum()
    
    run_records = []
    for rid, group in df[df['is_running']].groupby('run_id'):
        start_t = group['timestamp'].iloc[0]
        end_t = group['timestamp'].iloc[-1]
        dur_h = (end_t - start_t).total_seconds() / 3600.0
        dur_m = (end_t - start_t).total_seconds() / 60.0
        mean_p = group['power_kw'].mean()
        max_p = group['power_kw'].max()
        start_hr = start_t.hour + (start_t.minute / 60.0)
        
        run_records.append({
            'run_id': rid,
            'start_time': start_t,
            'end_time': end_t,
            'duration_hours': round(dur_h, 2),
            'duration_minutes': round(dur_m, 1),
            'mean_power_kw': round(mean_p, 2),
            'max_power_kw': round(max_p, 2),
            'start_hour': round(start_hr, 2)
        })
        
    return pd.DataFrame(run_records)


def cluster_run_periods(run_df: pd.DataFrame, n_clusters: int = 3) -> Tuple[pd.DataFrame, Dict[int, Dict[str, Any]]]:
    """
    Applies K-Means clustering on run cycles using:
    - duration_hours
    - mean_power_kw
    - start_hour
    """
    clust_df = run_df.copy()
    features = ['duration_hours', 'mean_power_kw', 'start_hour']
    
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(clust_df[features])
    
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    clust_df['cluster'] = kmeans.fit_predict(X_scaled)
    
    # Sort cluster IDs by mean duration so clusters are deterministic:
    # 0 = short midday, 1 = full 24h duty run, 2 = early morning
    cluster_means = clust_df.groupby('cluster')['duration_hours'].mean().sort_values()
    remap = {old: new for new, old in enumerate(cluster_means.index)}
    clust_df['cluster'] = clust_df['cluster'].map(remap)
    
    cluster_profiles = {}
    cluster_labels = {
        0: 'Midday Peaking / Top-Up Runs (~2-3 hrs)',
        1: 'Pre-Dawn / Early Morning Runs (~3-4 hrs)',
        2: 'Full 24-Hour Duty Rotation Runs (~20-24 hrs)'
    }
    
    for c in sorted(clust_df['cluster'].unique()):
        sub = clust_df[clust_df['cluster'] == c]
        cluster_profiles[c] = {
            'label': cluster_labels.get(c, f'Cluster {c}'),
            'count': int(len(sub)),
            'mean_duration_hours': round(float(sub['duration_hours'].mean()), 2),
            'mean_power_kw': round(float(sub['mean_power_kw'].mean()), 2),
            'mean_start_hour': round(float(sub['start_hour'].mean()), 2),
            'min_duration_hours': round(float(sub['duration_hours'].min()), 2),
            'max_duration_hours': round(float(sub['duration_hours'].max()), 2)
        }
        
    clust_df['cluster_label'] = clust_df['cluster'].map(cluster_labels)
    return clust_df, cluster_profiles

