"""
Power Forecasting Models and Evaluation Module (Task C1)
"""

import pandas as pd
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from typing import Dict, Any, Tuple


def train_test_split_temporal(df_features: pd.DataFrame, split_date: str = '2026-10-25 00:00:00') -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Splits the time series strictly by timestamp:
    Train: start through 24 Oct 23:45
    Test: 25 Oct 00:00 through 31 Oct 23:45 (final test week)
    
    Why random split would be wrong:
    Random cross-validation or random shuffling leaks future information into the past
    and destroys autocorrelation, diurnal autocorrelation, and lag structure.
    Time series evaluation must preserve temporal causality (train on past, evaluate on future).
    """
    train = df_features[df_features.index < split_date].copy()
    test = df_features[df_features.index >= split_date].copy()
    return train, test


def evaluate_forecast(y_true: pd.Series, y_pred: pd.Series, lag_1: pd.Series = None) -> Dict[str, Any]:
    """
    Computes regression evaluation metrics (MAE, RMSE, R2) overall,
    and isolates performance on transition moments vs steady-state operation.
    """
    mae = float(mean_absolute_error(y_true, y_pred))
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    r2 = float(r2_score(y_true, y_pred))
    
    res = {
        'mae': round(mae, 2),
        'rmse': round(rmse, 2),
        'r2': round(r2, 4)
    }
    
    # If lag_1 is provided, analyze steady-state vs start-up/shut-down transition performance
    if lag_1 is not None:
        is_turn_on = (lag_1 < 10.0) & (y_true >= 10.0)
        is_turn_off = (lag_1 >= 10.0) & (y_true < 10.0)
        is_transition = is_turn_on | is_turn_off
        
        abs_err = (y_true - y_pred).abs()
        transition_mae = float(abs_err[is_transition].mean()) if is_transition.sum() > 0 else 0.0
        steady_mae = float(abs_err[~is_transition].mean()) if (~is_transition).sum() > 0 else 0.0
        
        res['transition_mae'] = round(transition_mae, 2)
        res['steady_mae'] = round(steady_mae, 2)
        res['transition_count'] = int(is_transition.sum())
        
    return res


def run_forecasting_experiment(train: pd.DataFrame, test: pd.DataFrame, features: list) -> Dict[str, Any]:
    """
    Trains and compares:
    1. Baseline 1: Persistence (y_hat = lag_1)
    2. Baseline 2: 24-hr Seasonal Persistence (y_hat = lag_96)
    3. Linear Ridge Regression
    4. Random Forest Regressor
    5. Gradient Boosting Regressor
    """
    X_train, y_train = train[features], train['power_kw']
    X_test, y_test = test[features], test['power_kw']
    
    # 1. Baseline Persistence
    pred_base_pers = test['lag_1']
    metrics_base_pers = evaluate_forecast(y_test, pred_base_pers, test['lag_1'])
    
    # 2. Baseline Seasonal (same time yesterday)
    pred_base_seas = test['lag_96']
    metrics_base_seas = evaluate_forecast(y_test, pred_base_seas, test['lag_1'])
    
    # 3. Ridge Regression
    ridge = Ridge(alpha=1.0)
    ridge.fit(X_train, y_train)
    pred_ridge = pd.Series(ridge.predict(X_test), index=test.index)
    metrics_ridge = evaluate_forecast(y_test, pred_ridge, test['lag_1'])
    
    # 4. Random Forest
    rf = RandomForestRegressor(n_estimators=100, max_depth=10, random_state=42)
    rf.fit(X_train, y_train)
    pred_rf = pd.Series(rf.predict(X_test), index=test.index)
    metrics_rf = evaluate_forecast(y_test, pred_rf, test['lag_1'])
    
    # 5. Gradient Boosting Regressor
    gb = GradientBoostingRegressor(n_estimators=100, max_depth=4, learning_rate=0.05, random_state=42)
    gb.fit(X_train, y_train)
    pred_gb = pd.Series(gb.predict(X_test), index=test.index)
    metrics_gb = evaluate_forecast(y_test, pred_gb, test['lag_1'])
    
    # Feature importances
    feature_importance = pd.Series(gb.feature_importances_, index=features).sort_values(ascending=False).to_dict()
    
    predictions_df = pd.DataFrame({
        'actual': y_test,
        'persistence': pred_base_pers,
        'seasonal': pred_base_seas,
        'ridge': pred_ridge,
        'random_forest': pred_rf,
        'gradient_boosting': pred_gb,
        'lag_1': test['lag_1']
    }, index=test.index)
    
    return {
        'metrics': {
            'Baseline (Persistence t-1)': metrics_base_pers,
            'Baseline (Seasonal t-96)': metrics_base_seas,
            'Ridge Regression': metrics_ridge,
            'Random Forest': metrics_rf,
            'Gradient Boosting': metrics_gb
        },
        'predictions': predictions_df,
        'feature_importance': feature_importance,
        'best_model': gb
    }

