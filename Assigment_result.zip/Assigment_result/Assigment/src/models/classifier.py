"""
15-Minute Chiller On/Off State Classification Module (Stretch Task 2)
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, precision_recall_fscore_support
from typing import Dict, Any, Tuple


def train_eval_on_off_classifier(resampled_15: pd.DataFrame, split_date: str = '2026-10-25 00:00:00') -> Dict[str, Any]:
    """
    Trains a Random Forest classifier to predict whether the chiller
    will be ON (is_running = 1) or OFF (is_running = 0) in the next 15-minute interval.
    
    Features:
    - lag_1_on, lag_2_on, lag_4_on, lag_96_on
    - hour of day, day of week
    """
    df = resampled_15.copy()
    df['is_on'] = (df['power_kw'] >= 10.0).astype(int)
    
    # Lag features of state
    df['lag_1_on'] = df['is_on'].shift(1)
    df['lag_2_on'] = df['is_on'].shift(2)
    df['lag_4_on'] = df['is_on'].shift(4)
    df['lag_96_on'] = df['is_on'].shift(96)
    df['hour'] = df.index.hour
    df['dayofweek'] = df.index.dayofweek
    
    clean_df = df.dropna().copy()
    features = ['lag_1_on', 'lag_2_on', 'lag_4_on', 'lag_96_on', 'hour', 'dayofweek']
    
    train = clean_df[clean_df.index < split_date]
    test = clean_df[clean_df.index >= split_date]
    
    X_train, y_train = train[features], train['is_on']
    X_test, y_test = test[features], test['is_on']
    
    clf = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42)
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    
    prec, rec, f1, _ = precision_recall_fscore_support(y_test, y_pred, average='binary', pos_label=1)
    prec_macro, rec_macro, f1_macro, _ = precision_recall_fscore_support(y_test, y_pred, average='macro')
    acc = float((y_test == y_pred).mean())
    cm = confusion_matrix(y_test, y_pred).tolist()
    
    return {
        'accuracy': round(acc, 4),
        'on_precision': round(float(prec), 4),
        'on_recall': round(float(rec), 4),
        'on_f1': round(float(f1), 4),
        'macro_f1': round(float(f1_macro), 4),
        'confusion_matrix': cm,
        'classification_report_str': classification_report(y_test, y_pred, digits=4),
        'feature_importance': pd.Series(clf.feature_importances_, index=features).to_dict()
    }

