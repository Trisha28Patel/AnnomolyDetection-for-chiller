"""
Data Cleaning and Tidy Transformation Module
"""

import pandas as pd
import numpy as np
from typing import Tuple, List


def clean_chiller_data(df: pd.DataFrame, running_threshold_kw: float = 10.0, v_ll: float = 415.0) -> Tuple[pd.DataFrame, List[str]]:
    """
    Applies systematic data cleaning rules and returns a tidy DataFrame
    with standardized snake_case column names and derived engineering variables.
    
    List of transformations applied:
    1. Parse 'Timestamp' column with DD-MM-YYYY HH:MM into datetime index/column.
    2. Sort chronologically and drop any index artifacts.
    3. Drop completely uninformative zero-variance columns:
       - 'Apparent Power R (kVA)'
       - 'Apparent Power Y (kVA)'
       - 'Apparent Power B (kVA)'
       - 'Apparent Power (kVA)'
       - 'Apparent Energy (kVAh)'
    4. Rename raw columns to clean, lowercase, underscore-delimited names:
       - 'Active Power (kW)' -> 'power_kw'
       - 'Active Power R (kW)' -> 'power_r_kw'
       - 'Active Power Y (kW)' -> 'power_y_kw'
       - 'Active power B (kW)' -> 'power_b_kw'
       - 'Average Current (A)' -> 'current_avg_a'
       - 'Current R (A)' -> 'current_r_a'
       - 'Current Y (A)' -> 'current_y_a'
       - 'Current B (A)' -> 'current_b_a'
       - 'Active Energy (kWh)' -> 'active_energy_kwh'
    5. Compute sampling delta in hours ('delta_hours') based on true timestamp diffs.
    6. Derive operational status flag 'is_running' using the justified threshold (10.0 kW).
    7. Calculate phase current imbalance percentage:
       Imbalance % = (max(|I_phase - I_avg|) / I_avg) * 100
    8. Estimate Power Factor (PF) during running periods:
       PF = (P * 1000) / (sqrt(3) * V_LL * I_avg)
    9. Calculate phase power consistency discrepancy:
       power_mismatch_kw = |power_kw - (power_r_kw + power_y_kw + power_b_kw)|
    """
    changes_log = []
    
    # 1. Parse timestamps
    tidy = df.copy()
    tidy['timestamp'] = pd.to_datetime(tidy['Timestamp'], format='%d-%m-%Y %H:%M')
    tidy = tidy.sort_values('timestamp').reset_index(drop=True)
    changes_log.append("Parsed 'Timestamp' (DD-MM-YYYY HH:MM) into datetime64[ns] and sorted chronologically.")
    
    # 2. Drop zero columns
    cols_to_drop = [
        'Timestamp',
        'Apparent Power R (kVA)',
        'Apparent Power Y (kVA)',
        'Apparent Power B (kVA)',
        'Apparent Power (kVA)',
        'Apparent Energy (kVAh)'
    ]
    existing_drop = [c for c in cols_to_drop if c in tidy.columns]
    tidy = tidy.drop(columns=existing_drop)
    changes_log.append(f"Dropped {len(existing_drop)} uninformative columns ({', '.join(existing_drop)}).")
    
    # 3. Rename columns
    rename_map = {
        'Active Power (kW)': 'power_kw',
        'Active Power R (kW)': 'power_r_kw',
        'Active Power Y (kW)': 'power_y_kw',
        'Active power B (kW)': 'power_b_kw',
        'Average Current (A)': 'current_avg_a',
        'Current R (A)': 'current_r_a',
        'Current Y (A)': 'current_y_a',
        'Current B (A)': 'current_b_a',
        'Active Energy (kWh)': 'active_energy_kwh'
    }
    tidy = tidy.rename(columns=rename_map)
    changes_log.append("Renamed 9 electrical measurement columns to snake_case.")
    
    # 4. Compute delta hours (handling first row with median 2 min = 2/60 h)
    dt_diff_sec = tidy['timestamp'].diff().dt.total_seconds().fillna(120.0)
    tidy['delta_hours'] = dt_diff_sec / 3600.0
    changes_log.append("Computed exact time interval per reading in hours ('delta_hours').")
    
    # 5. Derive running state
    tidy['is_running'] = tidy['power_kw'] >= running_threshold_kw
    changes_log.append(f"Derived boolean operational status 'is_running' (threshold: {running_threshold_kw} kW).")
    
    # 6. Derive Phase Current Imbalance %
    dev_r = (tidy['current_r_a'] - tidy['current_avg_a']).abs()
    dev_y = (tidy['current_y_a'] - tidy['current_avg_a']).abs()
    dev_b = (tidy['current_b_a'] - tidy['current_avg_a']).abs()
    max_dev = np.maximum(dev_r, np.maximum(dev_y, dev_b))
    
    # Safe division when current is 0
    with np.errstate(divide='ignore', invalid='ignore'):
        imbalance = np.where(tidy['current_avg_a'] > 1.0, (max_dev / tidy['current_avg_a']) * 100.0, 0.0)
    tidy['current_imbalance_pct'] = np.round(imbalance, 2)
    changes_log.append("Calculated 3-phase current imbalance percentage ('current_imbalance_pct').")
    
    # 7. Derive Power Factor
    with np.errstate(divide='ignore', invalid='ignore'):
        pf_calc = (tidy['power_kw'] * 1000.0) / (np.sqrt(3) * v_ll * tidy['current_avg_a'])
        pf_calc = np.where((tidy['is_running']) & (tidy['current_avg_a'] > 5.0), np.clip(pf_calc, 0.0, 1.0), np.nan)
    tidy['power_factor'] = np.round(pf_calc, 4)
    changes_log.append("Estimated 3-phase power factor ('power_factor') for running periods.")
    
    # 8. Power mismatch between total and sum of phases
    sum_p = tidy['power_r_kw'] + tidy['power_y_kw'] + tidy['power_b_kw']
    tidy['power_mismatch_kw'] = (tidy['power_kw'] - sum_p).abs().round(2)
    changes_log.append("Computed instantaneous phase sum mismatch ('power_mismatch_kw').")
    
    return tidy, changes_log

