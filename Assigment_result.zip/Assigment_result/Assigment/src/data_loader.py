"""
Data Loading and Quality Inspection Module
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, Tuple


def load_raw_data(file_path: str = 'Chiller 1-2026-10-01_to_2026-10-31.csv') -> pd.DataFrame:
    """
    Load raw CSV export and parse initial timestamp.
    """
    df = pd.read_csv(file_path)
    return df


def audit_data_quality(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Perform a complete Part A data quality audit on raw dataframe.
    """
    total_rows = len(df)
    
    # 1. Timestamp parsing
    dt_series = pd.to_datetime(df['Timestamp'], format='%d-%m-%Y %H:%M')
    first_timestamp = dt_series.min()
    last_timestamp = dt_series.max()
    
    # 2. Missing values and duplicates
    missing_counts = df.isnull().sum().to_dict()
    total_missing = sum(missing_counts.values())
    duplicate_count = int(dt_series.duplicated().sum())
    
    # 3. Sampling regularity
    dt_sorted = dt_series.sort_values().reset_index(drop=True)
    intervals_min = dt_sorted.diff().dt.total_seconds().dropna() / 60.0
    
    interval_stats = {
        'mean_interval_min': float(intervals_min.mean()),
        'median_interval_min': float(intervals_min.median()),
        'min_interval_min': float(intervals_min.min()),
        'max_interval_min': float(intervals_min.max()),
        'std_interval_min': float(intervals_min.std()),
        'gaps_gt_10_count': int((intervals_min > 10.0).sum()),
        'distribution': intervals_min.round(1).value_counts().to_dict()
    }
    
    # 4. Zero / uninformative columns
    zero_columns = [col for col in df.columns if col != 'Timestamp' and (df[col] == 0).all()]
    
    # 5. Internal consistency checks
    # Power sum check: P_total == P_R + P_Y + P_B
    sum_phases = df['Active Power R (kW)'] + df['Active Power Y (kW)'] + df['Active power B (kW)']
    power_diff = (df['Active Power (kW)'] - sum_phases).abs()
    power_diff_gt_1kw = int((power_diff > 1.0).sum())
    max_power_diff = float(power_diff.max())
    mean_power_diff = float(power_diff.mean())
    
    # Current mean check: I_avg == (I_R + I_Y + I_B) / 3
    mean_phases_curr = (df['Current R (A)'] + df['Current Y (A)'] + df['Current B (A)']) / 3.0
    curr_diff = (df['Average Current (A)'] - mean_phases_curr).abs()
    curr_diff_gt_0_1a = int((curr_diff > 0.1).sum())
    max_curr_diff = float(curr_diff.max())
    mean_curr_diff = float(curr_diff.mean())
    
    # Active Energy monotonicity check
    energy_diff = df['Active Energy (kWh)'].diff().dropna()
    negative_energy_steps = int((energy_diff < 0).sum())
    start_energy = float(df['Active Energy (kWh)'].iloc[0])
    end_energy = float(df['Active Energy (kWh)'].iloc[-1])
    total_energy_counter = end_energy - start_energy
    
    return {
        'total_rows': total_rows,
        'first_timestamp': str(first_timestamp),
        'last_timestamp': str(last_timestamp),
        'total_missing': total_missing,
        'missing_by_column': missing_counts,
        'duplicate_timestamps': duplicate_count,
        'interval_stats': interval_stats,
        'zero_columns': zero_columns,
        'power_consistency': {
            'rows_differ_gt_1kw': power_diff_gt_1kw,
            'max_diff_kw': max_power_diff,
            'mean_diff_kw': mean_power_diff
        },
        'current_consistency': {
            'rows_differ_gt_0_1a': curr_diff_gt_0_1a,
            'max_diff_a': max_curr_diff,
            'mean_diff_a': mean_curr_diff
        },
        'energy_monotonicity': {
            'negative_steps_count': negative_energy_steps,
            'start_kwh': start_energy,
            'end_kwh': end_energy,
            'counter_delta_kwh': total_energy_counter
        }
    }

