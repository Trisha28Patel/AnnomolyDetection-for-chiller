# Technical Findings Report: Industrial Chiller Energy Analysis & Machine Learning

**Author:** Data Science & Energy Analytics Intern  
**Date:** 24 November 2026  
**Plant Asset:** Chiller 1 — Commercial Central Plant  
**Telemetry Period:** 01 October 2026 to 31 October 2026 (22,408 readings)  
**Tariff:** ₹8.50 per kWh  

---

## 1. Executive Summary

This report evaluates one month of 2-minute interval smart electrical meter telemetry from **Chiller 1**, an industrial chiller operating at a commercial facility. The objective was to audit and clean messy sensor data, characterize operational regimes, forecast short-term power demand using machine learning, detect electrical/operational anomalies, and recommend actionable energy-saving measures.

### Key Operational Numbers
* **Total Energy Consumed:** **52,220.99 kWh** (meter counter) vs **52,213.20 kWh** (numerical integration), agreeing within **0.015%**.
* **Electricity Cost:** **₹4,43,878.41** at ₹8.50/kWh.
* **Chiller Running Hours:** **245.37 hours** (equivalent to **32.98%** of the month) across **25 separate run periods**.
* **Average Standby Parasite Draw:** **0.0037 kW** (max 7.82 kW; over 99% of standby readings are 0.00 kW).
* **Average Running Power:** **212.79 kW** (ranging between 150 kW and 321.19 kW).
* **Diurnal Peak Hour:** **11:00 AM IST** (mean running demand: **267.77 kW**).
* **Average Running Power Factor:** **0.877** (sub-optimal; below utility 0.90 threshold).
* **Mean Phase Current Imbalance:** **3.50%** (15.9% of running readings exceed 5.0% motor limit).

---

## 2. Part A: Data Quality & Cleaning Audit

### 2.1 Telemetry Characteristics & Sampling Regularity
* **Timestamps:** 22,408 rows parsed strictly as `DD-MM-YYYY HH:MM` local time (IST).
* **Data Completeness:** **0 missing values** across all columns; **0 duplicate timestamps**.
* **Sampling Regularity:** The meter logs approximately every 2 minutes (mean: 1.992 min; 19,445 readings at 2.0 min, 1,578 at 1.0 min, 1,375 at 3.0 min). The maximum gap observed is **7.0 minutes**, meaning **zero gaps exceed 10 minutes**.
* **Impact of Irregular Intervals:** Time-series numerical energy integration requires variable $\Delta t_i$ weighting. For ML forecasting, data must be regularized into a uniform grid (15-minute mean power).

### 2.2 Uninformative Registers
Five columns contain **100% zeroes**: `Apparent Power R (kVA)`, `Apparent Power Y (kVA)`, `Apparent Power B (kVA)`, `Apparent Power (kVA)`, and `Apparent Energy (kVAh)`. This occurred because the apparent power Modbus register points were either unconfigured, disabled, or unmapped on the IoT gateway. These columns were dropped.

### 2.3 Physical Conservation Law Checks
1. **Active Power Balance ($P_{total} = P_R + P_Y + P_B$):** Matches on 99.1% of readings (mean discrepancy: 0.032 kW). Only 203 rows (0.9%) differ by $>1$ kW due to asynchronous digital register latching during rapid motor ramp-up/down.
2. **Current Mean ($I_{avg} = \frac{I_R + I_Y + I_B}{3}$):** Mean deviation is 0.078 A (max 6.79 A during start-up inrush).
3. **Active Energy Monotonicity:** Zero negative resets or downward jumps. Strictly monotonic from 384,139.71 to 436,360.70 kWh.

---

## 3. Part B: Exploratory Data Analysis & Engineering Insights

### 3.1 Operating Pattern & Duty Rotation
Analysis of daily energy across October reveals that chiller operation is **not** driven by day of the week (e.g. weekdays vs weekends). For example, Sunday Oct 18 ran a full 24-hr cycle (3,448 kWh), while several weekdays were completely idle (0.02 kWh).

**Operational Explanation:** Chiller 1 operates on a **lead-lag duty rotation schedule** with other facility chillers (Chiller 2, Chiller 3). It typically runs a continuous 24-hour cycle from **06:00 AM to 06:00 AM the following morning**, followed by 24 to 48 hours of rest while other chillers take base load. This rotation equalizes compressor run-hours and mechanical bearing/seal wear across the chiller fleet.

### 3.2 Diurnal Profile
Cooling load ramps from 161 kW at night to a peak of **267.77 kW at 11:00 AM**, remaining elevated above 250 kW through 2:00 PM. This correlates directly with solar radiation, daytime ambient dry-bulb temperature peaks in October, and building internal occupancy loads.

### 3.3 Phase Balance & Power Factor
* **Phase Current Imbalance:** Averages **3.50%**, but **15.9% of running readings (1,180 points)** exceed the 5.0% NEMA/IEEE standard for electric motors. Phase Y systematically carries higher current than Phase R. Sustained imbalance accelerates stator insulation degradation.
* **Power Factor:** Averages **0.877** during running periods (ranging 0.85–0.90, dipping to 0.70 on startup). Because Indian state electricity utilities levy surcharges below 0.90 PF and provide rebates above 0.95 PF, the facility is losing money on low-PF penalties.

---

## 4. Part C: Machine Learning Models

### 4.1 Task C1 — 15-Minute Ahead Power Forecasting
* **Data Resampling:** Resampled 2-minute data to 15-minute mean power (2,976 intervals; 0 missing intervals).
* **Features:** Lags ($t-1, t-2, t-4, t-8, t-96$), 1h and 24h rolling averages and standard deviation, sine/cosine cyclical hour encodings, day of week, and prior running state.
* **Evaluation Split:** Train on Oct 01–24 (2,208 intervals); Test on Oct 25–31 (672 intervals). A random split would cause severe temporal data leakage and invalidate autocorrelation modeling.

| Model / Baseline | MAE (kW) | RMSE (kW) | $R^2$ Score | Steady-State MAE (kW) | Transition MAE (kW) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Baseline: Persistence ($t-1$)** | 7.04 | 27.18 | 0.9009 | 5.62 | 59.88 |
| **Baseline: Seasonal ($t-96$, yesterday)** | 113.98 | 157.45 | -2.3210 | 112.50 | 148.20 |
| **Linear Ridge Regression** | 8.69 | 25.45 | 0.9131 | 7.35 | 58.12 |
| **Random Forest Regressor** | 9.85 | 22.12 | 0.9344 | 8.21 | 55.40 |
| **Gradient Boosting Regressor (GBR)** | **7.34** | **20.70** | **0.9426** | **6.00** | **65.79** |

* **Insights:** GBR achieves the lowest RMSE (20.70 kW, a 24% reduction over persistence). Seasonal persistence ($t-96$) fails completely because the chiller alternates days in duty rotation.
* **Error Concentration:** Steady-state prediction error is only **6.00 kW**, while transition moments (sudden start-up from 0 to 180+ kW or shutdown to 0 kW) surge to **65.79 kW**.
* **Improving Transitions:** Requires forward-looking external signals: BMS scheduled dispatch commands, chiller sequencing state-machine variable, real-time wet-bulb weather forecasts, and facility occupancy calendars.

### 4.2 Task C2 — Anomaly Detection
An Isolation Forest was trained on running points using 4 features: Active Power, Phase Imbalance %, Power Factor, and Phase Sum Discrepancy. It flagged **112 points (1.51% of running time)**.

#### Top Three Flagged Events
1. **Event 1 (Normal Operating Transient):** `03-10-2026 06:27` — Power Factor dipped to 0.700 and current imbalance spiked to 17.62% during compressor startup after a 48-hour rest. This is an expected motor inrush/unloaded startup transient.
2. **Event 2 (Data / Telemetry Error):** `10-10-2026 06:22` — Chiller shut down to 0.65 kW and currents dropped to 2.09 A, yet Phase R active power register logged 36.45 kW (causing a 35.8 kW mismatch). Physically impossible for 2.11 A at 240V; caused by asynchronous Modbus register buffer latch delay.
3. **Event 3 (Potential Equipment Issue):** `28-10-2026 01:11 to 02:48` — Under steady-state nighttime load (~110–137 kW), phase current imbalance remained persistently between 7.1% and 7.5% (> 5% motor limit) for over 90 minutes. Phase Y carried 20–25 A more than Phase R and B. Indicates transformer phase voltage imbalance or contactor degradation requiring physical inspection.

---

## 5. Stretch Tasks: Operational Clustering & On/Off Classification

* **K-Means Operational Cycle Clustering ($K=3$):**  
  * *Cluster 1 (10 cycles):* Primary 24-hr Duty Runs (mean 19.8 hrs, 224.3 kW, starting at 06:20 AM).
  * *Cluster 0 (7 cycles):* Midday Peaking Runs (mean 2.9 hrs, 176.2 kW, starting at 12:35 PM).
  * *Cluster 2 (8 cycles):* Pre-Dawn Runs (mean 3.3 hrs, 177.2 kW, starting at 02:20 AM).
  * Perfectly validates the lead-lag rotation and peak-shaving regime discovered in B3.
* **15-Minute Forward On/Off Classifier:** Random Forest predicts whether the chiller is ON or OFF in the next interval with **98.07% Accuracy**, **0.9591 ON Precision**, **0.9647 ON Recall**, and **0.9619 F1-score**.

---

## 6. Actionable Recommendation to Cut Energy Cost

> **Recommendation: Install an Automatic Power Factor Correction (APFC) Capacitor Bank**  
> **Target:** Raise operating power factor from **0.877** to **$\ge 0.96$**.  
> **Savings:** Eliminates monthly utility low-PF surcharges and secures a 0.5%–1.0% DISCOM billing rebate, saving approximately **₹25,000–₹40,000 per year** on this chiller alone with a payback period under **9 months**.

