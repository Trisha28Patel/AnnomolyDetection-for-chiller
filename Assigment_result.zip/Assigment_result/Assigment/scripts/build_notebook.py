"""
Script to build comprehensive Jupyter Notebook (test.ipynb & notebooks/chiller_analysis_and_ml.ipynb)
"""

import json
import os

def make_cell(cell_type, source, outputs=None):
    if isinstance(source, str):
        lines = [line + '\n' for line in source.split('\n')]
        if lines:
            lines[-1] = lines[-1].rstrip('\n')
    else:
        lines = source
    cell = {
        'cell_type': cell_type,
        'metadata': {},
        'source': lines
    }
    if cell_type == 'code':
        cell['execution_count'] = None
        cell['outputs'] = outputs or []
    return cell

cells = []

# Cell 1: Title & Overview
cells.append(make_cell('markdown', """# Industrial Chiller Energy Data Analysis & Machine Learning
**Author:** Data Science & Energy Analytics Intern  
**Date:** November 2026  
**Dataset:** Smart Energy Meter Telemetry — Chiller 1 (Oct 01, 2026 to Oct 31, 2026)

---

### Executive Overview
This notebook presents an end-to-end industrial data science project analyzing electrical meter data from **Chiller 1**, an industrial refrigeration unit operating at a commercial facility. The objective is to:
1. **Audit and clean** raw sensor telemetry (handle sampling irregularities, investigate uninformative registers, and verify physical electrical consistency).
2. **Conduct exploratory analysis** into energy usage, electricity cost, running duty cycles, diurnal load profiles, phase current unbalance, and power factor.
3. **Develop Machine Learning models** to forecast 15-minute ahead power demand and detect abnormal operational events using multivariate anomaly detection.
4. **Implement stretch capabilities** including operational cycle clustering (K-Means), an On/Off state classifier, and an executive briefing note for the plant manager."""))

# Cell 2: Imports
cells.append(make_cell('code', """import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Set visual aesthetic
plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
plt.rcParams['figure.figsize'] = (12, 5)
plt.rcParams['font.size'] = 11

# Add current directory to path to import modular src package
if '.' not in sys.path:
    sys.path.append('.')

from src.data_loader import load_raw_data, audit_data_quality
from src.cleaner import clean_chiller_data
from src.features import resample_to_15min, build_forecasting_features
from src.models.forecaster import train_test_split_temporal, run_forecasting_experiment
from src.models.anomaly_detector import detect_chiller_anomalies, get_top_three_anomalous_events
from src.models.clustering import extract_run_periods, cluster_run_periods
from src.models.classifier import train_eval_on_off_classifier

print("Libraries and local modules imported successfully.")"""))

# Cell 3: Part A Header
cells.append(make_cell('markdown', """## Part A — Data Quality and Cleaning
Before any exploratory or predictive analysis, we conduct a comprehensive audit of the raw sensor data:
- Verify timestamp formatting, start/end bounds, and total row count.
- Check for missing values and duplicated timestamps.
- Evaluate sampling regularity and inspect gaps longer than 10 minutes.
- Identify uninformative zero-variance columns.
- Test physical conservation laws ($P_{total} = P_R + P_Y + P_B$, $I_{avg} = \\frac{I_R + I_Y + I_B}{3}$, and Active Energy monotonicity).
- Apply a tidy cleaning function."""))

# Cell 4: Part A Code
cells.append(make_cell('code', """# Load raw export and run quality audit
df_raw = load_raw_data('Chiller 1-2026-10-01_to_2026-10-31.csv')
audit = audit_data_quality(df_raw)

print(f"Total Rows: {audit['total_rows']:,}")
print(f"Timestamp Bounds: {audit['first_timestamp']} to {audit['last_timestamp']}")
print(f"Total Missing Values: {audit['total_missing']}")
print(f"Duplicate Timestamps: {audit['duplicate_timestamps']}")
print(f"Sampling Interval: Mean = {audit['interval_stats']['mean_interval_min']:.2f} min, Median = {audit['interval_stats']['median_interval_min']:.1f} min")
print(f"Sampling Gaps > 10 min: {audit['interval_stats']['gaps_gt_10_count']}")
print(f"Uninformative (Zero) Columns: {audit['zero_columns']}")
print(f"Power Balance Discrepancies (>1 kW): {audit['power_consistency']['rows_differ_gt_1kw']} rows (Max diff: {audit['power_consistency']['max_diff_kw']:.2f} kW)")
print(f"Active Energy Counter Monotonicity Violations: {audit['energy_monotonicity']['negative_steps_count']}")
print(f"Total Energy Counter Delta: {audit['energy_monotonicity']['counter_delta_kwh']:.2f} kWh")"""))

# Cell 5: Part A Cleaning Function Call
cells.append(make_cell('code', """# Clean data and inspect transformation log
tidy_df, clean_logs = clean_chiller_data(df_raw)
print("Transformations applied during cleaning:")
for log in clean_logs:
    print(f" - {log}")

tidy_df.head()"""))

# Cell 6: Part B Header
cells.append(make_cell('markdown', """## Part B — Exploratory Analysis & Engineering Insights

### B1: Energy and Cost Calculations
We compute monthly energy consumption in two ways:
1. **From the meter odometer counter:** $E_{counter} = E_{end} - E_{start}$
2. **By numerical integration over time:** $E_{integral} = \\sum_{i} P_i \\times \\Delta t_i$
We test if both agree and calculate the financial cost at the commercial tariff of **₹8.50 per kWh**."""))

# Cell 7: Part B1 Code
cells.append(make_cell('code', """# Energy comparison
counter_energy = audit['energy_monotonicity']['counter_delta_kwh']
# Trapezoidal numerical integration
p_avg = (tidy_df['power_kw'] + tidy_df['power_kw'].shift(1).fillna(tidy_df['power_kw'])) / 2.0
integrated_energy = (p_avg * tidy_df['delta_hours']).sum()
diff_energy = integrated_energy - counter_energy
diff_pct = (diff_energy / counter_energy) * 100.0

cost_counter = counter_energy * 8.50
cost_integral = integrated_energy * 8.50

print(f"Energy from Meter Counter:     {counter_energy:,.2f} kWh (Cost: INR {cost_counter:,.2f})")
print(f"Energy from Numerical Integral:{integrated_energy:,.2f} kWh (Cost: INR {cost_integral:,.2f})")
print(f"Discrepancy (Integral - Counter): {diff_energy:.2f} kWh ({diff_pct:.3f}%)")"""))

# Cell 8: Part B2 Header
cells.append(make_cell('markdown', """### B2: On/Off Behaviour & Operational Run Periods
**Threshold Justification:**  
When the chiller compressor runs, it draws between 150 kW and 321 kW. When off or in standby, the meter registers parasite electronics load between 0.00 kW and 7.82 kW (mean 0.004 kW). There are virtually no steady readings between 10 kW and 100 kW. Thus, a threshold of **10.0 kW** cleanly distinguishes compressor operation from standby/idle states without false positives."""))

# Cell 9: Part B2 Code
cells.append(make_cell('code', """# Run period extraction
run_df = extract_run_periods(tidy_df)
running_hours = tidy_df.loc[tidy_df['is_running'], 'delta_hours'].sum()
total_hours = tidy_df['delta_hours'].sum()
running_pct = (running_hours / total_hours) * 100.0
standby_pwr = tidy_df.loc[~tidy_df['is_running'], 'power_kw']

print(f"Total Chiller Running Time: {running_hours:.2f} hours out of {total_hours:.2f} hours ({running_pct:.2f}%)")
print(f"Total Separate Run Cycles:  {len(run_df)}")
print(f"Standby Power Stats: Mean = {standby_pwr.mean():.4f} kW, Median = {standby_pwr.median():.4f} kW, Max = {standby_pwr.max():.2f} kW")
run_df.head(10)"""))

# Cell 10: Part B3 Header
cells.append(make_cell('markdown', """### B3: Operating Pattern Analysis
We aggregate energy consumption by day across all 31 days of October to examine the operational pattern."""))

# Cell 11: Part B3 Code & Plot
cells.append(make_cell('code', """# Daily energy bar plot
tidy_df['date'] = tidy_df['timestamp'].dt.date
daily_energy = tidy_df.groupby('date').apply(
    lambda g: (g['power_kw'] * g['delta_hours']).sum(), include_groups=False
).reset_index(name='energy_kwh')
daily_energy['date_str'] = daily_energy['date'].astype(str)

plt.figure(figsize=(14, 5))
colors = ['#2ca02c' if v > 2000 else '#ff7f0e' if v > 100 else '#7f7f7f' for v in daily_energy['energy_kwh']]
plt.bar(daily_energy['date_str'], daily_energy['energy_kwh'], color=colors, edgecolor='black', alpha=0.85)
plt.xticks(rotation=45, ha='right')
plt.title('Daily Energy Consumption (kWh) — October 2026 (Clear Duty Rotation Pattern)', fontsize=14, fontweight='bold')
plt.ylabel('Energy Consumed (kWh)')
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()"""))

# Cell 12: Part B3 Narrative
cells.append(make_cell('markdown', """**Operational Pattern Finding (B3):**
- The pattern is **not** dictated by standard weekday/weekend calendars (e.g. Sunday Oct 18 ran 24 hours consuming 3,448 kWh, while several weekdays were idle).
- Instead, it exhibits a classic **lead-lag duty rotation schedule** across multiple chillers. Chiller 1 typically runs a continuous ~24-hour cycle from 06:00 AM to 06:00 AM the following morning (e.g., Oct 3-4, 6-7, 9-10, 12-13, 15-16, 18-19, 21-22, 24-25, 27-28, 30-31), alternating with other chillers (Chiller 2 and Chiller 3) to equalize cumulative run-hours and prevent localized component wear."""))

# Cell 13: Part B4 Diurnal Hourly Load Profile
cells.append(make_cell('markdown', """### B4: Time of Day Load Profile
When the chiller is running, how does power change by hour of day? When does the peak occur, and why? We evaluate the diurnal cycle."""))

# Cell 14: Part B4 Code & Plot
cells.append(make_cell('code', """df_run = tidy_df[tidy_df['is_running']].copy()
df_run['hour'] = df_run['timestamp'].dt.hour
hourly_stats = df_run.groupby('hour')['power_kw'].agg(
    mean='mean',
    median='median',
    p25=lambda x: x.quantile(0.25),
    p75=lambda x: x.quantile(0.75)
).reset_index()

plt.figure(figsize=(12, 5))
plt.plot(hourly_stats['hour'], hourly_stats['mean'], marker='o', color='#1f77b4', lw=2.5, label='Mean Power (kW)')
plt.fill_between(hourly_stats['hour'], hourly_stats['p25'], hourly_stats['p75'], color='#1f77b4', alpha=0.2, label='IQR (25th-75th Percentile)')
plt.xticks(range(0, 24))
plt.title('Chiller 1 Diurnal Running Power Profile by Hour of Day', fontsize=14, fontweight='bold')
plt.xlabel('Hour of Day (IST)')
plt.ylabel('Active Power (kW)')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

peak_hour = hourly_stats.loc[hourly_stats['mean'].idxmax()]
print(f"Peak Demand Hour: {int(peak_hour['hour']):02d}:00 IST with Mean Power = {peak_hour['mean']:.2f} kW")"""))

# Cell 15: Part B4 Narrative
cells.append(make_cell('markdown', """**Diurnal Finding (B4):**  
Peak cooling load occurs at **11:00 AM (mean 267.8 kW)** and remains elevated through 02:00 PM (> 250 kW). Nighttime running power is flat at ~161–175 kW.  
**Reason:** Solar thermal radiation through building glazing peaks in late morning, coinciding with ambient temperature rise in October and internal heat gains from arriving building occupants and office IT equipment."""))

# Cell 16: Part B5 & B6 Phase Balance & Power Factor
cells.append(make_cell('markdown', """### B5 & B6: Phase Current Imbalance & Power Factor
- **Phase Current Imbalance:** $\\text{Imbalance \\%} = \\frac{\\max(|I_{phase} - I_{avg}|)}{I_{avg}} \\times 100$
- **Power Factor:** $PF \\approx \\frac{P \\times 1000}{\\sqrt{3} \\times 415 \\times I_{avg}}$"""))

# Cell 17: Part B5 & B6 Code
cells.append(make_cell('code', """imb = df_run['current_imbalance_pct']
over_5 = (imb > 5.0).sum()
over_5_pct = (over_5 / len(df_run)) * 100.0

pf = df_run['power_factor'].dropna()

print(f"Phase Current Imbalance: Mean = {imb.mean():.2f}%, Median = {imb.median():.2f}%, Max = {imb.max():.2f}%")
print(f"Readings Exceeding 5.0% Limit: {over_5:,} / {len(df_run):,} ({over_5_pct:.2f}%)")
print(f"Running Power Factor: Mean = {pf.mean():.3f}, Median = {pf.median():.3f}, Min = {pf.min():.3f}, Max = {pf.max():.3f}")

# Plot histograms
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 4))
sns.histplot(imb, bins=40, ax=ax1, color='#ff7f0e', kde=True)
ax1.axvline(5.0, color='red', linestyle='--', lw=2, label='5% Motor Limit')
ax1.set_title('Phase Current Imbalance (%) Distribution')
ax1.legend()

sns.histplot(pf, bins=40, ax=ax2, color='#2ca02c', kde=True)
ax2.axvline(0.90, color='red', linestyle='--', lw=2, label='0.90 Utility Threshold')
ax2.set_title('Power Factor Distribution')
ax2.legend()
plt.tight_layout()
plt.show()"""))

# Cell 18: Part C Header
cells.append(make_cell('markdown', """## Part C — Machine Learning

### Resampling to 15-Minute Intervals
We aggregate the 2-minute sensor data to regular 15-minute intervals using interval mean power. Because the maximum sampling gap in October is 7.0 minutes, zero intervals are missing.

### Task C1 — Forecast Power for the Next 15 Minutes
We construct features:
- Lags: $t-1, t-2, t-4, t-8, t-96$
- Moving statistics: 1-hour and 24-hour rolling averages and std
- Cyclical calendar encodings and operational state indicators
- Chronological train/test split (Train: Oct 1-24, Test: Oct 25-31)."""))

# Cell 19: Part C1 Feature Engineering and Models
cells.append(make_cell('code', """s15 = resample_to_15min(tidy_df)
feat_df, feat_cols = build_forecasting_features(s15)
train, test = train_test_split_temporal(feat_df, '2026-10-25 00:00:00')

print(f"Train interval bounds: {train.index.min()} to {train.index.max()} ({len(train)} steps)")
print(f"Test interval bounds:  {test.index.min()} to {test.index.max()} ({len(test)} steps)")

forecast_res = run_forecasting_experiment(train, test, feat_cols)
metrics_df = pd.DataFrame(forecast_res['metrics']).T
metrics_df"""))

# Cell 20: Part C1 Plot
cells.append(make_cell('code', """preds = forecast_res['predictions']

plt.figure(figsize=(15, 5))
plt.plot(preds.index, preds['actual'], color='black', lw=2, label='Actual Power (kW)')
plt.plot(preds.index, preds['gradient_boosting'], color='#2ca02c', lw=1.8, label='Gradient Boosting (GBR)')
plt.plot(preds.index, preds['persistence'], color='#1f77b4', lw=1.2, linestyle=':', label='Persistence Baseline (t-1)')
plt.title('Task C1: 15-Minute Ahead Power Forecast vs Actual (Test Week: Oct 25–31)', fontsize=14, fontweight='bold')
plt.ylabel('Power (kW)')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

# Error breakdown
gbr_m = forecast_res['metrics']['Gradient Boosting']
print(f"Steady-State MAE:  {gbr_m['steady_mae']:.2f} kW")
print(f"Transition MAE:    {gbr_m['transition_mae']:.2f} kW")
print(f"Transition Count:  {gbr_m['transition_count']} steps")"""))

# Cell 21: Task C2 Anomaly Detection
cells.append(make_cell('markdown', """### Task C2 — Detect Unusual Behaviour During Running Periods
Isolation Forest is fitted on running data using multidimensional features: Active Power, Phase Current Imbalance, Power Factor, and Phase Sum Discrepancy."""))

# Cell 22: Task C2 Code
cells.append(make_cell('code', """df_run, anomalies_df, anom_stats = detect_chiller_anomalies(tidy_df, contamination=0.015)
top_events = get_top_three_anomalous_events(anomalies_df)

print(f"Total Running Points: {anom_stats['total_running_points']:,}")
print(f"Flagged Anomalies:    {anom_stats['flagged_count']:,} ({anom_stats['share_of_running_pct']:.2f}% of running time)")

# Print top 3 events
print("\\n" + "="*80)
print("DEEP-DIVE: TOP THREE ANOMALOUS OPERATING EVENTS")
print("="*80)
for ev in top_events:
    print(f"\\n[Event {ev['event_id']}] {ev['title']} at {ev['timestamp']}")
    print(f"Classification: {ev['classification']}")
    for k, v in ev['key_metrics'].items():
        print(f"  • {k}: {v}")
    print(f"Analysis: {ev['description']}")"""))

# Cell 23: Stretch Tasks Header
cells.append(make_cell('markdown', """## Stretch Tasks (Optional)

### Stretch 1: K-Means Run Period Clustering
Segmenting operating cycles into functional clusters based on duration, mean power, and start hour."""))

# Cell 24: Stretch 1 Code
cells.append(make_cell('code', """clust_df, clust_profiles = cluster_run_periods(run_df, n_clusters=3)

for cid, p in clust_profiles.items():
    print(f"\\nCluster {cid}: {p['label']}")
    print(f"  Count: {p['count']} cycles | Mean Duration: {p['mean_duration_hours']:.1f} hrs | Mean Power: {p['mean_power_kw']:.1f} kW | Mean Start Hour: {p['mean_start_hour']:.2f} IST")"""))

# Cell 25: Stretch 2 Code
cells.append(make_cell('markdown', """### Stretch 2: 15-Minute Forward On/Off State Classifier
Predicting binary operational state (ON vs OFF) for the next 15-minute interval."""))

# Cell 26: Stretch 2 Code
cells.append(make_cell('code', """clf_res = train_eval_on_off_classifier(s15, '2026-10-25 00:00:00')

print(f"Test Accuracy:    {clf_res['accuracy']*100:.2f}%")
print(f"ON Precision:     {clf_res['on_precision']:.4f}")
print(f"ON Recall:        {clf_res['on_recall']:.4f}")
print(f"Macro F1-Score:   {clf_res['macro_f1']:.4f}")
print("\\nClassification Report:\\n", clf_res['classification_report_str'])"""))

# Notebook structure
notebook = {
    'cells': cells,
    'metadata': {
        'kernelspec': {
            'display_name': 'Python 3',
            'language': 'python',
            'name': 'python3'
        },
        'language_info': {
            'codemirror_mode': {'name': 'ipython', 'version': 3},
            'file_extension': '.py',
            'mimetype': 'text/x-python',
            'name': 'python',
            'nbconvert_exporter': 'python',
            'pygments_lexer': 'ipython3',
            'version': '3.11.8'
        }
    },
    'nbformat': 4,
    'nbformat_minor': 5
}

os.makedirs('notebooks', exist_ok=True)
os.makedirs('scripts', exist_ok=True)

with open('test.ipynb', 'w', encoding='utf-8') as f:
    json.dump(notebook, f, indent=2)

with open('notebooks/chiller_analysis_and_ml.ipynb', 'w', encoding='utf-8') as f:
    json.dump(notebook, f, indent=2)

print("Generated test.ipynb and notebooks/chiller_analysis_and_ml.ipynb successfully.")

