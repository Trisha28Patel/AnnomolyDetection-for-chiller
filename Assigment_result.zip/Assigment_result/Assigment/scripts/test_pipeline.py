"""
End-to-End Pipeline Verification Script
Tests all components in src and app.py
"""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
print("Starting pipeline verification...")

# 1. Test data loading & audit
from src.data_loader import load_raw_data, audit_data_quality
df_raw = load_raw_data('Chiller 1-2026-10-01_to_2026-10-31.csv')
audit = audit_data_quality(df_raw)
assert audit['total_rows'] == 22408, f"Expected 22408 rows, got {audit['total_rows']}"
assert audit['total_missing'] == 0, "Expected 0 missing values"
assert audit['duplicate_timestamps'] == 0, "Expected 0 duplicates"
print("✓ Step 1: Data loader & quality audit passed.")

# 2. Test cleaner
from src.cleaner import clean_chiller_data
tidy_df, logs = clean_chiller_data(df_raw)
assert tidy_df.shape[0] == 22408, f"Expected 22408 rows in tidy df, got {tidy_df.shape[0]}"
assert 'power_kw' in tidy_df.columns, "Expected power_kw in tidy columns"
assert 'is_running' in tidy_df.columns, "Expected is_running in tidy columns"
assert 'current_imbalance_pct' in tidy_df.columns, "Expected current_imbalance_pct in tidy columns"
print(f"✓ Step 2: Cleaner passed ({len(logs)} changes applied).")

# 3. Test features & resampling
from src.features import resample_to_15min, build_forecasting_features
s15 = resample_to_15min(tidy_df)
assert s15.shape[0] == 2976, f"Expected 2976 15-min intervals, got {s15.shape[0]}"
feat_df, feat_cols = build_forecasting_features(s15)
assert len(feat_cols) > 10, "Expected >10 features"
print(f"✓ Step 3: 15-min resampling & feature engineering passed ({len(feat_cols)} features).")

# 4. Test forecasting
from src.models.forecaster import train_test_split_temporal, run_forecasting_experiment
train, test = train_test_split_temporal(feat_df, '2026-10-25 00:00:00')
assert len(test) == 672, f"Expected 672 test intervals (7 days * 96), got {len(test)}"
forecast_res = run_forecasting_experiment(train, test, feat_cols)
gbr_metrics = forecast_res['metrics']['Gradient Boosting']
assert gbr_metrics['rmse'] < 25.0, f"Expected GBR RMSE < 25 kW, got {gbr_metrics['rmse']}"
print(f"✓ Step 4: Forecasting models passed (GBR RMSE = {gbr_metrics['rmse']} kW, R2 = {gbr_metrics['r2']}).")

# 5. Test anomaly detection
from src.models.anomaly_detector import detect_chiller_anomalies, get_top_three_anomalous_events
df_run, anomalies_df, anom_stats = detect_chiller_anomalies(tidy_df, contamination=0.015)
assert len(anomalies_df) > 0, "Expected flagged anomalies"
top_events = get_top_three_anomalous_events(anomalies_df)
assert len(top_events) == 3, "Expected 3 top events"
print(f"✓ Step 5: Anomaly detection passed ({len(anomalies_df)} points flagged, top 3 events extracted).")

# 6. Test clustering & classifier
from src.models.clustering import extract_run_periods, cluster_run_periods
from src.models.classifier import train_eval_on_off_classifier
run_df = extract_run_periods(tidy_df)
clust_df, clust_profiles = cluster_run_periods(run_df, n_clusters=3)
assert len(clust_profiles) == 3, "Expected 3 clusters"

clf_res = train_eval_on_off_classifier(s15, '2026-10-25 00:00:00')
assert clf_res['accuracy'] > 0.95, f"Expected classifier accuracy > 95%, got {clf_res['accuracy']}"
print(f"✓ Step 6: Stretch tasks passed (Clustering: 3 clusters, On/Off Classifier Accuracy = {clf_res['accuracy']*100:.2f}%).")

# 7. Test visualizer
from src.visualizer import (
    plot_power_timeseries, plot_daily_energy, plot_hourly_load_profile,
    plot_phase_balance, plot_forecast_comparison, plot_anomaly_scatter
)
fig1 = plot_power_timeseries(tidy_df.head(100))
fig2 = plot_daily_energy(tidy_df)
fig3 = plot_hourly_load_profile(tidy_df)
fig4 = plot_phase_balance(tidy_df.head(100))
fig5 = plot_forecast_comparison(forecast_res['predictions'].head(50))
fig6 = plot_anomaly_scatter(tidy_df.head(100), anomalies_df.head(10))
print("✓ Step 7: Visualizer charts created successfully.")

print("\n🎉 ALL PIPELINE INTEGRATION TESTS PASSED WITH 100% SUCCESS!")
