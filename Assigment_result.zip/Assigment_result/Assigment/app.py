"""
Chiller Energy Intelligence & Predictive Analytics Dashboard
=============================================================
Interactive Web Application for Industrial Chiller Energy Data Analysis & Machine Learning
Compliant with Part A, B, C, D, and Stretch Tasks.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime

# Local package imports
from src.data_loader import load_raw_data, audit_data_quality
from src.cleaner import clean_chiller_data
from src.features import resample_to_15min, build_forecasting_features
from src.models.forecaster import train_test_split_temporal, run_forecasting_experiment
from src.models.anomaly_detector import detect_chiller_anomalies, get_top_three_anomalous_events
from src.models.clustering import extract_run_periods, cluster_run_periods
from src.models.classifier import train_eval_on_off_classifier
from src.visualizer import (
    plot_power_timeseries, plot_daily_energy, plot_hourly_load_profile,
    plot_phase_balance, plot_forecast_comparison, plot_anomaly_scatter
)

# Page configuration
st.set_page_config(
    page_title="Chiller 1 Energy Analytics & ML Dashboard",
    page_icon="❄️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS styling for polished UI
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1E3A8A;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.1rem;
        color: #4B5563;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background-color: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 8px;
        padding: 16px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .status-badge {
        padding: 4px 8px;
        border-radius: 4px;
        font-weight: 600;
        font-size: 0.85rem;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_data
def get_cached_data():
    """Load, audit, and clean data with caching."""
    df_raw = load_raw_data('Chiller 1-2026-10-01_to_2026-10-31.csv')
    audit = audit_data_quality(df_raw)
    tidy_df, clean_logs = clean_chiller_data(df_raw)
    return df_raw, audit, tidy_df, clean_logs


@st.cache_data
def get_forecasting_results(tidy_df):
    """Resample, build features, and run forecasting models with caching."""
    s15 = resample_to_15min(tidy_df)
    feat_df, feat_cols = build_forecasting_features(s15)
    train, test = train_test_split_temporal(feat_df, '2026-10-25 00:00:00')
    results = run_forecasting_experiment(train, test, feat_cols)
    return s15, feat_df, results


@st.cache_data
def get_anomaly_results(tidy_df):
    """Run anomaly detection and extract top events."""
    df_run, anomalies_df, stats = detect_chiller_anomalies(tidy_df, contamination=0.015)
    top_events = get_top_three_anomalous_events(anomalies_df)
    return df_run, anomalies_df, stats, top_events


@st.cache_data
def get_clustering_and_classifier_results(tidy_df, s15):
    """Run stretch tasks: run period clustering and On/Off classifier."""
    run_df = extract_run_periods(tidy_df)
    clust_df, clust_profiles = cluster_run_periods(run_df, n_clusters=3)
    clf_res = train_eval_on_off_classifier(s15, '2026-10-25 00:00:00')
    return run_df, clust_df, clust_profiles, clf_res


# Load all processed pipelines
try:
    df_raw, audit, tidy_df, clean_logs = get_cached_data()
    s15, feat_df, forecast_res = get_forecasting_results(tidy_df)
    df_run, anomalies_df, anom_stats, top_events = get_anomaly_results(tidy_df)
    run_df, clust_df, clust_profiles, clf_res = get_clustering_and_classifier_results(tidy_df, s15)
    data_loaded = True
except Exception as e:
    st.error(f"Error initializing data: {e}")
    data_loaded = False

# Sidebar Navigation
st.sidebar.image("https://img.icons8.com/fluency/96/air-conditioner.png", width=70)
st.sidebar.title("Navigation")
page = st.sidebar.radio(
    "Go to Section",
    [
        "📌 Overview & KPIs",
        "🔍 Exploratory Data Analysis",
        "📈 ML Power Forecast (Task C1)",
        "⚠️ Anomaly Detection (Task C2)",
        "🔄 Operational Cycles & Clustering",
        "📋 Note to the Plant Manager"
    ]
)

st.sidebar.markdown("---")
st.sidebar.caption("### Dataset Telemetry Status")
st.sidebar.info(
    f"**Source:** Chiller 1 Smart Energy Meter\n\n"
    f"**Period:** 01 Oct 2026 – 31 Oct 2026\n\n"
    f"**Total Records:** {len(tidy_df):,} rows\n\n"
    f"**Electricity Tariff:** ₹8.50 / kWh"
)

# Header Bar
st.markdown('<div class="main-header">Industrial Chiller Energy Analysis & Machine Learning</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Smart Energy Meter Telemetry, Predictive Forecasting, Anomaly Detection & Operations Optimization</div>', unsafe_allow_html=True)

if not data_loaded:
    st.stop()

# ==============================================================================
# SECTION 1: OVERVIEW & KPIS
# ==============================================================================
if page == "📌 Overview & KPIs":
    st.header("Executive Overview & Monthly Performance Metrics")
    
    # Compute Core KPIs
    counter_energy_kwh = audit['energy_monotonicity']['counter_delta_kwh']
    total_cost_inr = counter_energy_kwh * 8.50
    running_hours = (tidy_df.loc[tidy_df['is_running'], 'delta_hours']).sum()
    total_hours = tidy_df['delta_hours'].sum()
    running_pct = (running_hours / total_hours) * 100.0
    
    standby_df = tidy_df[~tidy_df['is_running']]
    mean_standby_kw = standby_df['power_kw'].mean()
    max_standby_kw = standby_df['power_kw'].max()
    
    running_df = tidy_df[tidy_df['is_running']]
    avg_running_pf = running_df['power_factor'].mean()
    avg_running_power = running_df['power_kw'].mean()
    peak_power = running_df['power_kw'].max()
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric(
            label="Total Active Energy",
            value=f"{counter_energy_kwh:,.1f} kWh",
            help="Cumulative active energy from meter odometer counter delta (384,139.71 to 436,360.70 kWh)"
        )
    with col2:
        st.metric(
            label="Total Electricity Cost",
            value=f"₹{total_cost_inr:,.2f}",
            help="Computed at the specified commercial tariff of ₹8.50 per kWh"
        )
    with col3:
        st.metric(
            label="Chiller Running Time",
            value=f"{running_hours:.1f} hrs ({running_pct:.1f}%)",
            delta=f"{len(run_df)} distinct run cycles",
            help="Total operational time above 10 kW out of 744.0 available hours in October"
        )
    with col4:
        st.metric(
            label="Average Standby Power",
            value=f"{mean_standby_kw:.3f} kW",
            delta=f"Max idle: {max_standby_kw:.2f} kW",
            delta_color="off",
            help="Base standby parasite draw when compressor is turned off"
        )

    col5, col6, col7, col8 = st.columns(4)
    with col5:
        st.metric(
            label="Avg Running Power",
            value=f"{avg_running_power:.1f} kW",
            help="Mean power drawn during active compressor operation"
        )
    with col6:
        st.metric(
            label="Peak Load Demand",
            value=f"{peak_power:.1f} kW",
            help="Highest recorded 2-minute power demand during October"
        )
    with col7:
        st.metric(
            label="Mean Running Power Factor",
            value=f"{avg_running_pf:.3f}",
            delta="-0.023 vs 0.90 Target",
            delta_color="inverse",
            help="Average power factor during running periods. Below typical DISCOM 0.90 penalty threshold."
        )
    with col8:
        mean_imbalance = running_df['current_imbalance_pct'].mean()
        st.metric(
            label="Mean Phase Imbalance",
            value=f"{mean_imbalance:.2f}%",
            delta="15.9% readings > 5% limit",
            delta_color="inverse",
            help="Mean 3-phase current deviation percentage while running"
        )

    st.markdown("---")
    st.subheader("Data Quality & Cleaning Audit Summary (Part A)")
    
    c_audit1, c_audit2 = st.columns([1, 1])
    with c_audit1:
        st.markdown(f"""
        **Dataset Integrity Findings:**
        - **Total Records:** {audit['total_rows']:,} rows spanning `01-10-2026 00:01` to `31-10-2026 23:59`.
        - **Missing Values:** **0** across all 15 columns.
        - **Duplicate Timestamps:** **0** duplicate records found.
        - **Sampling Frequency:** Median interval is **2.0 minutes** (19,445 readings at 2 min, 1,578 at 1 min, 1,375 at 3 min).
        - **Maximum Sampling Gap:** **7.0 minutes** (Zero gaps > 10 minutes).
        - **Energy Monotonicity:** Active Energy counter strictly non-decreasing (**0 resets, 0 backward jumps**).
        """)
        
    with c_audit2:
        st.markdown(f"""
        **Discrepancies & Adjustments Made:**
        - **Uninformative Columns Dropped:** All 5 Apparent Power/Energy columns (`kVA` and `kVAh`) were 100% zeroes due to unmapped Modbus registers.
        - **Phase Power Consistency:** Phase sum ($R + Y + B$) matches Total Active Power on 99.1% of rows. Only 203 rows (0.9%) differ by $>1$ kW due to asynchronous digital register update sampling during rapid load ramps.
        - **Current Mean Consistency:** Average Current matches $(I_R + I_Y + I_B)/3$ within 0.08 A average error.
        - **Tidy Transformation:** Standardized column names to snake_case and added physical engineering variables.
        """)

    with st.expander("View Complete Data Cleaning Pipeline Logs"):
        for log in clean_logs:
            st.markdown(f"- ✅ {log}")

# ==============================================================================
# SECTION 2: EXPLORATORY DATA ANALYSIS (PART B)
# ==============================================================================
elif page == "🔍 Exploratory Data Analysis":
    st.header("Part B — Exploratory Data Analysis & Engineering Insights")
    
    st.markdown("Use the interactive controls below to explore operational profiles and electrical characteristics.")
    
    # Date Range Filter
    min_date = tidy_df['timestamp'].dt.date.min()
    max_date = tidy_df['timestamp'].dt.date.max()
    
    c_filter1, c_filter2 = st.columns([1, 2])
    with c_filter1:
        date_range = st.date_input(
            "Select Date Filter Range:",
            value=(min_date, max_date),
            min_value=min_date,
            max_value=max_date
        )
    
    if isinstance(date_range, (tuple, list)) and len(date_range) == 2:
        start_sel, end_sel = date_range
    else:
        start_sel, end_sel = min_date, max_date
        
    filtered_df = tidy_df[
        (tidy_df['timestamp'].dt.date >= start_sel) &
        (tidy_df['timestamp'].dt.date <= end_sel)
    ]
    
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "⚡ Power Over Time",
        "📅 Daily Energy & Duty Cycles",
        "⏰ Diurnal Hourly Profile",
        "⚖️ Phase Current Imbalance",
        "🔋 Power Factor Analysis"
    ])
    
    with tab1:
        st.plotly_chart(plot_power_timeseries(filtered_df), use_container_width=True)
        st.caption("💡 **Takeaway:** Chiller 1 operates at ~150–320 kW when active and draws 0.00 kW on standby. Compressor cycling shows prolonged steady runs punctuated by complete shutdowns.")

    with tab2:
        st.plotly_chart(plot_daily_energy(filtered_df), use_container_width=True)
        st.markdown("""
        **Engineering Operating Pattern Insight (B3):**
        - The energy pattern is **not** driven by the day of the week (e.g. weekdays vs weekends). For example, Sunday Oct 18 ran a full 24-hr cycle consuming 3,448 kWh, while Sunday Oct 11 and Sunday Oct 25 were mostly idle.
        - Instead, the data reveals an **alternating 3-day / 2-day duty rotation cycle** between multiple chillers (Chiller 1, Chiller 2, and Chiller 3).
        - Chiller 1 typically runs a continuous 24-hour cycle from **06:00 AM to 06:00 AM the following morning**, followed by 24 to 48 hours of rest while other chillers take the lead load. This lead-lag rotation equalizes compressor run-hours and mechanical wear across the plant.
        """)

    with tab3:
        st.plotly_chart(plot_hourly_load_profile(filtered_df), use_container_width=True)
        st.markdown("""
        **Diurnal Load Profile Insight (B4):**
        - Mean power demand peaks at **11:00 AM (267.8 kW)** and remains elevated between 10:00 AM and 02:00 PM (> 255 kW).
        - In the pre-dawn hours (00:00 - 05:00), running power is stable at ~161–175 kW (nighttime baseload).
        - **Why:** The midday surge directly tracks solar heat gain on the building envelope, peak ambient dry-bulb temperatures in October, and office occupancy/plug loads requiring higher chilled water circulation.
        """)

    with tab4:
        st.plotly_chart(plot_phase_balance(filtered_df), use_container_width=True)
        st.markdown("""
        **Phase Balance Insight (B5):**
        - Mean current imbalance while running is **3.50%**, with 84.1% of readings safely below the standard 5.0% NEMA motor design limit.
        - However, **15.9% of running readings (1,180 readings)** exceed the 5.0% threshold, reaching up to 17.62% during start-up inrush.
        - Phase Y systematically draws more current than Phase R and B. Prolonged operation above 5% causes excessive rotor heating and decreases motor insulation life.
        """)

    with tab5:
        pf_run = filtered_df[filtered_df['is_running']]['power_factor'].dropna()
        fig_pf = px.histogram(
            pf_run, x='power_factor', nbins=50,
            title='Power Factor Distribution During Running Periods',
            labels={'power_factor': 'Power Factor (0 to 1)'},
            color_discrete_sequence=['#2b5c8f']
        )
        fig_pf.add_vline(x=0.90, line_dash='dash', line_color='red', annotation_text='0.90 DISCOM Penalty Limit')
        fig_pf.update_layout(template='plotly_white', height=400)
        st.plotly_chart(fig_pf, use_container_width=True)
        st.markdown("""
        **Power Factor Insight (B6):**
        - The power factor concentrates between **0.87 and 0.89** (mean 0.877), dipping to ~0.70 during start-up inrush.
        - **Recommendation:** In India, commercial electricity tariffs mandate a minimum power factor of 0.90 or 0.95. Operating at 0.87–0.88 incurs monthly low-PF penalties. Installing an **Automatic Power Factor Correction (APFC) capacitor bank** to raise PF to $\ge 0.96$ will eliminate penalties and earn DISCOM billing rebates.
        """)

# ==============================================================================
# SECTION 3: ML POWER FORECAST (TASK C1)
# ==============================================================================
elif page == "📈 ML Power Forecast (Task C1)":
    st.header("Part C — Machine Learning Task C1: 15-Minute Power Forecasting")
    
    st.markdown("""
    **Objective:** Forecast active power (kW) for the next 15-minute interval ($t$) based on historical telemetry.  
    **Evaluation Split:** Strict chronological split — **Train:** Oct 01–24 (2,208 intervals) | **Test:** Oct 25–31 (672 intervals).  
    *A random split would cause severe temporal data leakage and destroy autocorrelation structures.*
    """)
    
    metrics_dict = forecast_res['metrics']
    pred_df = forecast_res['predictions']
    
    # Model comparison table
    st.subheader("Model Benchmark Performance (Test Week: Oct 25–31)")
    
    comp_data = []
    for model_name, m in metrics_dict.items():
        comp_data.append({
            'Model / Baseline': model_name,
            'MAE (kW)': f"{m['mae']:.2f}",
            'RMSE (kW)': f"{m['rmse']:.2f}",
            'R² Score': f"{m['r2']:.4f}",
            'Steady-State MAE (kW)': f"{m.get('steady_mae', 0):.2f}",
            'Transition MAE (kW)': f"{m.get('transition_mae', 0):.2f}"
        })
    comp_table = pd.DataFrame(comp_data)
    st.table(comp_table)
    
    st.subheader("Interactive Actual vs Predicted Forecast (Test Week)")
    st.plotly_chart(plot_forecast_comparison(pred_df), use_container_width=True)
    
    c_err1, c_err2 = st.columns([1, 1])
    with c_err1:
        st.markdown("### Where Does the Model Make Errors?")
        st.info("""
        - **Steady-State Accuracy:** When the chiller remains steadily ON or steadily OFF, the Gradient Boosting model is exceptionally accurate (**MAE = 6.00 kW**).
        - **Transition Spike:** During start-up (0 kW $\\to$ 180+ kW) and shut-down (200 kW $\\to$ 0 kW) moments, the error surges 11-fold (**MAE = 65.79 kW**).
        - **Lag-96 Seasonal Failure:** The 24-hr seasonal baseline performs terribly (MAE = 114 kW, RMSE = 157 kW) because the chiller alternates days; yesterday's state is often the opposite of today's state!
        """)
        
    with c_err2:
        st.markdown("### What is Needed to Predict Transitions Better?")
        st.success("""
        To accurately predict chiller start-up and shut-down moments, the model requires external forward-looking signals:
        1. **Central BMS Staging / Scheduling Commands:** Scheduled dispatch signals from the building automation system.
        2. **Chiller Plant State Machine:** An operational variable indicating which chiller is active in the duty rotation roster.
        3. **Real-Time Weather / Wet-Bulb Forecasts:** Forward outdoor temperature forecasts driving predicted cooling loads.
        4. **Building Occupancy Calendars:** Knowing meeting room bookings and commercial facility hours.
        """)

    st.markdown("### Top Feature Importances (Gradient Boosting)")
    feat_imp = pd.Series(forecast_res['feature_importance']).sort_values(ascending=False).head(8)
    fig_imp = px.bar(
        x=feat_imp.values, y=feat_imp.index, orientation='h',
        labels={'x': 'Relative Importance', 'y': 'Feature'},
        title='Gradient Boosting Regressor — Key Drivers of Power Forecast',
        color_discrete_sequence=['#1f77b4']
    )
    fig_imp.update_layout(template='plotly_white', height=350, yaxis=dict(autorange="reversed"))
    st.plotly_chart(fig_imp, use_container_width=True)

# ==============================================================================
# SECTION 4: ANOMALY DETECTION (TASK C2)
# ==============================================================================
elif page == "⚠️ Anomaly Detection (Task C2)":
    st.header("Part C — Machine Learning Task C2: Anomaly Detection During Running Periods")
    
    st.markdown("""
    **Methodology:** Isolation Forest fitted exclusively on running periods ($P \\ge 10$ kW) using 4 multidimensional features:
    1. Total Active Power (kW)
    2. Phase Current Imbalance (%)
    3. Power Factor (PF)
    4. Instantaneous Phase Sum Mismatch ($|P_{total} - \\sum P_{phase}|$)
    """)
    
    c_an1, c_an2, c_an3 = st.columns(3)
    with c_an1:
        st.metric("Total Running Points Evaluated", f"{anom_stats['total_running_points']:,}")
    with c_an2:
        st.metric("Flagged Anomaly Points", f"{anom_stats['flagged_count']:,}")
    with c_an3:
        st.metric("Share of Running Time Flagged", f"{anom_stats['share_of_running_pct']:.2f}%")
        
    st.plotly_chart(plot_anomaly_scatter(tidy_df, anomalies_df), use_container_width=True)
    
    st.subheader("Deep-Dive: Top Three Most Unusual Operating Events")
    
    for ev in top_events:
        with st.expander(f"Event #{ev['event_id']}: {ev['title']} ({ev['timestamp']})", expanded=True):
            col_e1, col_e2 = st.columns([1, 2])
            with col_e1:
                st.markdown(f"**Classification:** `{ev['classification']}`")
                st.markdown("**Key Metrics:**")
                for k, v in ev['key_metrics'].items():
                    st.markdown(f"- **{k}:** {v}")
            with col_e2:
                st.markdown(f"**Root-Cause Engineering Explanation:**\n\n{ev['description']}")

# ==============================================================================
# SECTION 5: OPERATIONAL CYCLES & CLUSTERING (STRETCH TASKS)
# ==============================================================================
elif page == "🔄 Operational Cycles & Clustering":
    st.header("Stretch Tasks: Operational Cycle Clustering & 15-Minute State Classifier")
    
    tab_st1, tab_st2 = st.tabs(["🧩 K-Means Run Period Clustering", "🎯 15-Min On/Off State Classifier"])
    
    with tab_st1:
        st.subheader("Operational Run Period Clustering (K-Means)")
        st.markdown("""
        Continuous running periods were extracted and segmented with K-Means ($K=3$) using:
        - **Duration (hours)**, **Mean Power (kW)**, and **Start Hour of Day**.
        """)
        
        # Display cluster cards
        c_cols = st.columns(len(clust_profiles))
        for idx, (cid, p) in enumerate(clust_profiles.items()):
            with c_cols[idx]:
                st.markdown(f"#### {p['label']}")
                st.write(f"**Occurrences:** {p['count']} runs")
                st.write(f"**Mean Duration:** {p['mean_duration_hours']:.1f} hours")
                st.write(f"**Mean Load:** {p['mean_power_kw']:.1f} kW")
                st.write(f"**Mean Start Time:** {int(p['mean_start_hour']):02d}:{int((p['mean_start_hour']%1)*60):02d} IST")
                
        # Scatter plot of clusters
        fig_cl = px.scatter(
            clust_df, x='duration_hours', y='mean_power_kw',
            color='cluster_label', size='max_power_kw',
            hover_data=['start_time', 'end_time', 'start_hour'],
            labels={'duration_hours': 'Run Duration (hours)', 'mean_power_kw': 'Mean Power (kW)', 'cluster_label': 'Operational Regime'},
            title='Chiller Run Period Clusters: 24h Duty Runs vs Midday vs Pre-Dawn Cycles'
        )
        fig_cl.update_layout(template='plotly_white', height=450)
        st.plotly_chart(fig_cl, use_container_width=True)
        
        st.info("📌 **Conclusion:** The clusters perfectly align with the plant's operational design: Cluster 2 represents primary 24-hr lead duty rotations (~20–24 hrs at ~224 kW starting at 06:00 AM), while Clusters 0 and 1 represent auxiliary midday top-ups and pre-dawn pulls.")

    with tab_st2:
        st.subheader("15-Minute Forward On/Off State Classifier")
        st.markdown("""
        Trained a Random Forest Classifier to predict whether the chiller will be **ON** ($P \\ge 10$ kW) or **OFF** ($P < 10$ kW) in the upcoming 15-minute interval.
        """)
        
        c_cl1, c_cl2, c_cl3, c_cl4 = st.columns(4)
        with c_cl1:
            st.metric("Test Accuracy", f"{clf_res['accuracy']*100:.2f}%")
        with c_cl2:
            st.metric("ON Precision", f"{clf_res['on_precision']:.4f}")
        with c_cl3:
            st.metric("ON Recall", f"{clf_res['on_recall']:.4f}")
        with c_cl4:
            st.metric("Macro F1-Score", f"{clf_res['macro_f1']:.4f}")
            
        st.text("Detailed Classification Report on Test Week (Oct 25–31):")
        st.code(clf_res['classification_report_str'])

# ==============================================================================
# SECTION 6: NOTE TO THE PLANT MANAGER
# ==============================================================================
elif page == "📋 Note to the Plant Manager":
    st.header("Executive Briefing Note for the Facility & Plant Manager")
    st.caption("Plain-English Operational Summary · Zero Jargon · Actionable Energy Cost Reduction")
    
    st.markdown("""
    ---
    ### 📝 MEMORANDUM
    **TO:** Central Plant Operations & Facility Management  
    **FROM:** Industrial Energy Analytics Team  
    **DATE:** 24 November 2026  
    **SUBJECT:** Chiller 1 Operational Performance, Electrical Health, and Cost Reduction Opportunities  
    ---
    
    ### 1. Executive Summary
    During October 2026, **Chiller 1 consumed 52,221 kWh of electricity**, costing **₹4,43,878** at your commercial tariff of ₹8.50 per kWh. The machine ran for **245.4 hours (33.0% of the month)** across 25 distinct operating cycles. When shut down, it draws zero wasted standby power (less than 4 watts).
    
    ---
    
    ### 2. Top Three Operational Findings
    
    1. **Chiller Duty-Rotation Schedule is Working as Intended:**
       - Chiller 1 does not run every day. It follows a disciplined alternating 2-to-3-day rotation, running a continuous ~24-hour cycle from 6:00 AM to 6:00 AM the next morning, then resting while other chillers take over.
       - Daily electricity bills swing from virtually ₹0 on rest days to ~₹40,000 on full-run days. This confirms effective wear-equalization across the chiller fleet.
    
    2. **Midday Cooling Demand Peaks Consistently at 11:00 AM:**
       - Whenever the chiller is running, electricity demand increases steadily through the morning, peaking at 11:00 AM with an average load of **268 kW** (reaching up to 321 kW).
       - This matches building occupancy arrival and outdoor solar heating. Cooling load eases off after 5:00 PM down to 170 kW overnight.
    
    3. **Phase Current Imbalance and Power Factor Need Attention:**
       - In 16% of operating readings, the electric current across the three power phases was uneven by more than 5%, with one line carrying noticeably more load than the others.
       - The chiller operates with an average power factor of **0.877**, which is below the standard utility threshold of 0.90 to 0.95.
    
    ---
    
    ### 3. Concrete Recommendation to Cut Energy Costs
    
    > **Action Item: Install an Automatic Power Factor Correction (APFC) Capacitor Bank**
    > 
    > **The Problem:** Your local electricity provider penalizes industrial facilities when power factor drops below 0.90 and offers tariff rebates when power factor stays above 0.95. Operating at 0.88 means you are paying avoidable monthly surcharges and wasting energy as wire heat.
    > 
    > **The Solution:** Install a 60–80 kVAR automatic capacitor bank at the chiller electrical panel to correct the power factor from 0.88 to 0.98.
    > 
    > **Financial Impact:** 
    > - Eliminates monthly low-power-factor utility penalties.
    > - Earns an estimated **0.5% to 1.0% prompt billing rebate** on your monthly electricity bill, saving approximately **₹25,000 to ₹40,000 annually** on this chiller alone.
    > - Typical hardware payback period is **less than 6 to 9 months**.
    
    ---
    """)
    
st.markdown("---")
st.caption("Industrial Chiller Energy Analysis & ML System · Built with Python & Streamlit")

