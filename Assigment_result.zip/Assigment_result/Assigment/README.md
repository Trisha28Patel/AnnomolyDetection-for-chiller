# Industrial Chiller Energy Data Analysis & Machine Learning

[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://streamlit.io/)
[![Python 3.11](https://img.shields.io/badge/python-3.11-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

An end-to-end industrial data science project evaluating one month (22,408 readings) of high-frequency smart electrical meter data from **Chiller 1**, an industrial refrigeration compressor at a commercial facility.

This repository provides:
1. **Interactive Web Application (`app.py`):** Multi-tab Streamlit dashboard with Overview, Exploratory Data Analysis, ML Forecasting, Anomaly Detection, Operational Clustering, and Plant Manager Briefing.
2. **Analysis & Modeling Notebook (`test.ipynb` & `notebooks/chiller_analysis_and_ml.ipynb`):** Step-by-step Jupyter notebook covering Parts A, B, C, and Stretch Tasks with mathematical formulas, data cleaning, and visualizations.
3. **Modular Python Package (`src/`):** Production-grade modules for data loading, quality auditing, cleaning, feature engineering, forecasting, anomaly detection, and clustering.
4. **Executive Findings Write-Up (`REPORT.md`):** Complete 4-page findings report summarizing numerical results, engineering takeaways, and cost-reduction recommendations.

---

## 📊 Key Executive Findings

| Metric | Measured Value | Operational & Financial Significance |
| :--- | :---: | :--- |
| **Total Active Energy (Month)** | **52,220.99 kWh** | Odometer counter matches numerical integral within **0.015%** (-7.79 kWh). |
| **Total Electricity Bill** | **₹4,43,878.41** | Computed at standard commercial tariff of ₹8.50 per kWh. |
| **Total Running Hours** | **245.37 hrs (32.98%)** | Machine ran ~1/3 of October across 25 discrete operational cycles. |
| **Average Standby Power** | **0.0037 kW** | Parasite standby draw is negligible (<4 Watts; >99% readings are 0.00 kW). |
| **Average Running Power** | **212.79 kW** | Compressor active load ranges between 150 kW and 321.19 kW. |
| **Diurnal Peak Hour** | **11:00 AM IST** | Mean running power peaks at 267.77 kW due to solar and occupancy loads. |
| **Running Power Factor** | **0.877** | Sub-optimal. Below utility 0.90 threshold, incurring low-PF penalty fees. |
| **Phase Current Imbalance** | **3.50% avg** | 15.9% of running readings exceed the 5.0% NEMA motor design limit. |
| **Forecasting Model (GBR)** | **RMSE: 20.70 kW** | 24% error reduction vs persistence baseline ($R^2 = 0.9426$). |
| **On/Off State Classifier** | **98.07% Accuracy** | Predicts whether chiller is ON/OFF in next 15 minutes ($F_1 = 0.9619$). |

---

## 🛠️ Repository Architecture

```
.
├── app.py                             # Interactive Streamlit Web Application
├── test.ipynb                         # Complete Analysis & Modeling Notebook (Active Workspace Document)
├── notebooks/
│   └── chiller_analysis_and_ml.ipynb  # Clean copy of complete Jupyter Notebook
├── REPORT.md                          # Executive Technical Findings Report (< 4 pages)
├── README.md                          # Complete Project Guide & Documentation
├── requirements.txt                   # Production Python Dependencies
├── .gitignore                         # Standard git ignore definitions
├── Chiller 1-2026-10-01_to_2026-10-31.csv # Raw Smart Energy Meter Telemetry
├── scripts/
│   └── build_notebook.py              # Script to build and format Jupyter Notebook
└── src/                               # Modular Python Package
    ├── __init__.py
    ├── data_loader.py                 # Data loading and Part A quality audit
    ├── cleaner.py                     # Systematic cleaning returning tidy DataFrame
    ├── features.py                    # 15-min resampling & lag/rolling feature engineering
    ├── visualizer.py                  # Publication-quality interactive Plotly figures
    └── models/
        ├── __init__.py
        ├── forecaster.py              # Task C1: Baseline, Ridge, RF, GBR models & evaluation
        ├── anomaly_detector.py        # Task C2: Isolation Forest & top 3 unusual events
        ├── clustering.py              # Stretch 1: K-Means run period clustering
        └── classifier.py              # Stretch 2: 15-min On/Off Random Forest classifier
```

---

## 🚀 Quick Start: Running Locally

### 1. Clone Repository & Set Up Environment
```bash
git clone https://github.com/your-username/chiller-energy-ml.git
cd chiller-energy-ml

# Create virtual environment (optional but recommended)
python -m venv venv
# Windows:
venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Launch Streamlit Web Application
```bash
streamlit run app.py
```
Open your browser at `http://localhost:8501`.

### 3. Open Analysis Notebook
Open `test.ipynb` or `notebooks/chiller_analysis_and_ml.ipynb` in VS Code or JupyterLab:
```bash
jupyter notebook test.ipynb
```

---

## 🌐 Free Platform Cloud Deployment Guide

The web application is fully self-contained and loads the dataset directly from the repository. You can deploy it for free within 5 minutes on any of the following platforms:

### Option A: Streamlit Community Cloud (Recommended)
1. Push this repository to your personal public GitHub account:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Chiller energy analytics and ML project"
   git remote add origin https://github.com/<your-username>/chiller-energy-ml.git
   git branch -M main
   git push -u origin main
   ```
2. Navigate to [share.streamlit.io](https://share.streamlit.io/) and log in with your GitHub account.
3. Click **"New app"**.
4. Select your repository (`<your-username>/chiller-energy-ml`), branch (`main`), and set the main file path to `app.py`.
5. Click **"Deploy!"**.
> **Note on Free Tier Sleeping:** Streamlit Community Cloud apps go to sleep when idle after several days. If sleeping, the wake-up time is typically **15 to 30 seconds** on first click.

### Option B: Hugging Face Spaces (Free)
1. Go to [huggingface.co/spaces](https://huggingface.co/spaces) and click **"Create new Space"**.
2. Select **Streamlit** as the Space SDK and choose **Public**.
3. Clone the space repo or connect your GitHub repo, and push the files.

### Option C: Render.com (Free Web Service)
1. Create a free account at [render.com](https://render.com/).
2. Select **"New Web Service"** and link your GitHub repository.
3. Configure:
   - **Environment:** `Python 3`
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `streamlit run app.py --server.port $PORT --server.address 0.0.0.0`
4. Deploy!

---

## 🔬 Detailed Project Solutions & Methodology

### Part A: Data Quality & Cleaning
* **Missing & Duplicates:** Verified 0 null values and 0 duplicate timestamps across all 22,408 rows.
* **Sampling Distribution:** Median gap is 2.0 minutes. Zero gaps exceed 10 minutes (maximum gap is 7.0 minutes).
* **Uninformative Registers:** Identified that Apparent Power (R, Y, B, Total) and Apparent Energy are 100% zeroes due to unmapped Modbus register addresses. These columns were cleanly dropped.
* **Internal Consistency Checks:**
  * Total Active Power matches $P_R + P_Y + P_B$ within 0.032 kW average deviation. Only 203 rows differ by $>1$ kW due to asynchronous digital register update sampling during rapid load ramps.
  * Active Energy is strictly monotonic with 0 negative resets or counter jumps.
* **Cleaning Function:** Implemented `clean_chiller_data()` in `src/cleaner.py` applying snake_case renaming, physical delta calculations, and derived metrics.

### Part B: Exploratory Analysis & Engineering Insights
* **B1 (Energy & Cost):** Counter delta = 52,220.99 kWh; Trapezoidal numerical integral = 52,213.20 kWh (difference: -7.79 kWh or -0.015%). Cost = **₹4,43,878.41** at ₹8.50/kWh.
* **B2 (On/Off Behaviour):** Justified **10.0 kW** threshold (compressor operates at 150–321 kW; standby parasite draw averages 0.0037 kW). Running time = **245.37 hours (32.98%)** across **25 separate run periods**.
* **B3 (Operating Pattern):** Daily energy is **not** dictated by weekday vs weekend calendars. Instead, Chiller 1 operates on a **lead-lag duty rotation schedule** with other facility chillers (running continuous ~24-hour cycles from 06:00 AM to 06:00 AM every 2–3 days) to equalize mechanical compressor wear.
* **B4 (Diurnal Profile):** Power demand peaks at **11:00 AM (mean 267.8 kW)** and stays elevated through 02:00 PM (>250 kW), driven by solar radiation through glazing, ambient temperature rise in October, and internal building occupancy loads.
* **B5 (Phase Balance):** Mean current imbalance is 3.50%. However, 15.9% of running readings exceed the 5% NEMA motor limit, with Phase Y carrying systematically more current than Phase R.
* **B6 (Power Factor):** Mean PF is 0.877 (falling to ~0.70 on startup). Strongly recommend an **Automatic Power Factor Correction (APFC) panel** to bring PF to $\ge 0.96$ and avoid utility surcharges.

### Part C: Machine Learning
* **15-Minute Resampling:** Cleaned data was aggregated to 15-minute mean power. Because max gap was 7.0 minutes, 100% of the 2,976 intervals contained active readings (0 missing intervals).
* **Task C1 (Forecasting):** Evaluated Persistence Baseline ($t-1$), Seasonal Baseline ($t-96$), Ridge Regression, Random Forest, and Gradient Boosting on a strict chronological test split (Oct 01–24 train; Oct 25–31 test).
  * **Gradient Boosting Regressor achieved best performance: MAE = 7.34 kW, RMSE = 20.70 kW, $R^2 = 0.9426$** (a 24% RMSE reduction over persistence).
  * **Transition Analysis:** Steady-state error was only **6.00 kW**, while transition moments (startup/shutdown) had an MAE of **65.79 kW**. Accurate transition forecasting requires external signals: BMS scheduled dispatch commands, chiller sequencing controller status, weather forecasts, and building occupancy calendars.
* **Task C2 (Anomaly Detection):** Isolation Forest on running points flagged 112 points (1.51% of running time). Identified top 3 events:
  1. *Motor Start-up Inrush Transient:* `03-10-2026 06:27` (PF = 0.700, Imbalance = 17.62%).
  2. *Data / Sensor Latch Delay Error:* `10-10-2026 06:22` (Chiller shut down to 0.65 kW, but Phase R register was stuck at 36.45 kW).
  3. *Equipment Phase Unbalance Issue:* `28-10-2026 01:11–02:48` (Sustained current unbalance $>7.1\%$ under steady 110–137 kW load for $>90$ minutes).

### Stretch Tasks
* **Operational Cycle Clustering:** K-Means ($K=3$) segmented runs into:
  1. *24-Hour Duty Rotation Runs:* Mean duration 19.8 hrs, 224.3 kW, starting at 06:20 AM.
  2. *Midday Peaking Runs:* Mean duration 2.9 hrs, 176.2 kW, starting at 12:35 PM.
  3. *Pre-Dawn Runs:* Mean duration 3.3 hrs, 177.2 kW, starting at 02:20 AM.
* **15-Minute On/Off Classifier:** Random Forest achieved **98.07% Accuracy**, **0.9591 ON Precision**, **0.9647 ON Recall**, and **0.9619 F1-score**.
* **Plant Manager Note:** Executive memo delivered in the web dashboard and report providing zero-jargon findings and a concrete APFC capacitor bank recommendation saving ₹25,000–₹40,000 annually with $<9$-month payback.

---

## 👥 Authorship & Submission

* **Author:** Data Science & Energy Analytics Intern
* **Role:** Intern Assignment Submission — Chiller Energy Data Analysis & ML
* **Date:** 24 November 2026

